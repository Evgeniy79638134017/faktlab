"""Local, portable backups. Standard library only; no network or credentials."""
from __future__ import annotations
import argparse,contextlib,ctypes,hashlib,json,os,re,shutil,stat,subprocess,sys,time,uuid,zipfile
from pathlib import Path,PurePosixPath
from datetime import date,datetime,timezone

ROOT_FILES={'ПРИНЦИПЫ_ОБУЧЕНИЯ.md','AGENTS.md','НАЧАТЬ.md','СОСТОЯНИЕ.md','РОЛЬ_АГЕНТА.md','МАНИФЕСТ.json','КАК_РАБОТАТЬ.html'}
ROOT_DIRS={'ПРОЕКТЫ','ДАННЫЕ','ДНЕВНИК','УЧЁБА','ЦЕЛИ','ИССЛЕДОВАНИЕ','МАТЕРИАЛЫ','ПОРТФОЛИО','ОБУЧЕНИЕ_АГЕНТУ','ЗАМЕТКИ','tools','.agents','ChatGPT'}
SKIP_PARTS={'.git','.runtime','.backups','__pycache__','node_modules','.venv','venv'}
SECRET=re.compile(r'(^\.env($|\.)|(^|[._-])(credentials?|secrets?|tokens?|passwords?)([._-]|$)|\.(session|pem|key|pfx|p12)$)',re.I)
VERSION='school-backup-1.0'
ARCHIVE_NAME=re.compile(r'school-\d{8}T\d{12}Z-[0-9a-f]{6}\.zip')
MAX_PAYLOAD_BYTES=512*1024*1024
MATERIAL_FILE_LIMIT=32*1024*1024

def configure_output():
 # The CLI protocol is UTF-8 even when the parent console requests cp1251.
 for stream in (sys.stdout,sys.stderr):
  if hasattr(stream,'reconfigure'):stream.reconfigure(encoding='utf-8',errors='backslashreplace')

def stamp():return datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
def now():return datetime.now(timezone.utc).isoformat()
def sha(data):return hashlib.sha256(data).hexdigest()
def json_bytes(data):return json.dumps(data,ensure_ascii=False,indent=2).encode('utf-8')
def atomic_json(path,data):
 path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
 tmp.write_bytes(json_bytes(data))
 try:
  for attempt in range(8):
   try:tmp.replace(path);break
   except PermissionError:
    # Windows readers/security scanners can briefly hold the destination.
    # Retry the same atomic replacement; never weaken permissions or truncate it.
    if attempt==7:raise
    time.sleep(.025*(attempt+1))
 finally:
  if tmp.exists():tmp.unlink()
def linked(path):
 path=Path(path)
 if path.is_symlink():return True
 try:return bool(getattr(path.stat(follow_symlinks=False),'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',1024))
 except FileNotFoundError:return False
def alive(pid):
 try:
  pid=int(pid)
  if pid<=0:return False
  if os.name!='nt':os.kill(pid,0);return True
  kernel=ctypes.WinDLL('kernel32',use_last_error=True)
  kernel.OpenProcess.argtypes=[ctypes.c_uint32,ctypes.c_int,ctypes.c_uint32];kernel.OpenProcess.restype=ctypes.c_void_p
  handle=kernel.OpenProcess(0x1000,False,pid)
  if not handle:return False
  try:
   code=ctypes.c_uint32();kernel.GetExitCodeProcess.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_uint32)]
   return bool(kernel.GetExitCodeProcess(handle,ctypes.byref(code))) and code.value==259
  finally:
   kernel.CloseHandle.argtypes=[ctypes.c_void_p];kernel.CloseHandle(handle)
 except (OSError,ValueError,TypeError):return False
def comparison_path(path):
 # Normalize equivalent Windows extended drive/UNC spellings only.
 value=str(path)
 if os.name=='nt':
  prefix=chr(92)*2+'?'+chr(92)
  if value.startswith(prefix+'UNC'+chr(92)):value=chr(92)*2+value[8:]
  elif value.startswith(prefix) and len(value)>=7 and value[4].isalpha() and value[5:7]==':'+chr(92):value=value[4:]
 return Path(value)
def internal(root,rel):
 root=Path(root).resolve();target=root/rel
 # Refuse linked internal directories even when the final file does not exist.
 for part in [target,*target.parents]:
  if part==root:break
  if linked(part):raise ValueError('Linked internal path is not allowed: '+str(part))
 resolved_target=target.resolve()
 if not comparison_path(resolved_target).is_relative_to(comparison_path(root)):raise ValueError('Path leaves workspace')
 return target
def allowed(name):
 if '\\' in name or ':' in name or name.startswith('/') or not name:return False
 path=PurePosixPath(name)
 if any(x in ('','..','.') for x in name.split('/')):return False
 if any(x in SKIP_PARTS or SECRET.search(x) for x in path.parts):return False
 return (len(path.parts)==1 and name in ROOT_FILES) or (len(path.parts)>1 and path.parts[0] in ROOT_DIRS)
def files(root):
 root=Path(root).resolve();result=[]
 for name in sorted(ROOT_FILES|ROOT_DIRS):
  item=root/name
  if linked(item):raise ValueError('Linked source is not backed up: '+name)
  if item.is_file():result.append(item)
  elif item.is_dir():
   for base,dirs,names in os.walk(item,followlinks=False):
    base=Path(base)
    for d in dirs:
     if d not in SKIP_PARTS and not SECRET.search(d) and linked(base/d):raise ValueError('Linked source directory rejected: '+str(base/d))
    dirs[:]=sorted(d for d in dirs if d not in SKIP_PARTS and not SECRET.search(d))
    for filename in sorted(names):
     p=base/filename
     if linked(p):raise ValueError('Linked source file rejected: '+str(p))
     if not p.resolve().is_relative_to(root):raise ValueError('Source leaves workspace: '+str(p))
     if allowed(p.relative_to(root).as_posix()):result.append(p)
 return sorted(result,key=lambda f:f.relative_to(root).as_posix())
def payload(root,with_omissions=False):
 root=Path(root).resolve()
 # Enumerate/guard every allowed path before selecting anything. Even a large
 # source must never bypass link or secret checks because it will be omitted.
 entries=[]
 for path in files(root):
  stat_before=path.stat();name=path.relative_to(root).as_posix()
  entries.append((name,path,stat_before.st_size,stat_before.st_mtime_ns))
 selected={name:(path,size,mtime) for name,path,size,mtime in entries};omitted={}
 def omit(name,reason):
  path,size,mtime=selected.pop(name)
  omitted[name]={'path':name,'bytes':size,'mtime_ns':mtime,'reason':reason,'content_verified':False}
 # Only source material in this dedicated directory is eligible. State,
 # instructions, journals and portfolio work remain mandatory.
 for name,path,size,mtime in entries:
  if name.startswith('МАТЕРИАЛЫ/') and size>MATERIAL_FILE_LIMIT:omit(name,'material_file_over_32_mib')
 total=sum(item[1] for item in selected.values())
 if total>MAX_PAYLOAD_BYTES:
  candidates=sorted((name for name in selected if name.startswith('МАТЕРИАЛЫ/')),key=lambda n:(-selected[n][1],n))
  for name in candidates:
   if total<=MAX_PAYLOAD_BYTES:break
   total-=selected[name][1];omit(name,'material_aggregate_budget')
 if total>MAX_PAYLOAD_BYTES:raise ValueError('Required context exceeds 512 MiB; no context files were omitted')
 # A partial restore must stay partial until its missing originals are added.
 receipt=internal(root,'.runtime/migration-receipt.json')
 if receipt.exists():
  imported=json.loads(receipt.read_text('utf-8'));validate_omissions(imported.get('omissions',[]),{})
  for item in imported.get('omissions',[]):
   if not internal(root,item['path']).is_file():omitted.setdefault(item['path'],item)
 result={}
 for name,(path,size,mtime) in selected.items():
  # Read only after size preflight; cap the read if a file grows meanwhile.
  internal(root,name)
  with path.open('rb') as handle:data=handle.read(size+1)
  after=path.stat()
  if len(data)!=size or after.st_size!=size or after.st_mtime_ns!=mtime:raise RuntimeError('Workspace changed while reading; backup deferred')
  result[name]=data
 omissions=[omitted[name] for name in sorted(omitted)]
 return (result,omissions) if with_omissions else result

def coverage(meta):
 omissions=meta.get('omissions',[])
 return {'partial':bool(omissions),'omissions':omissions,'complete_for_backup_scope':not omissions,'warning_codes':['MATERIALS_OMITTED'] if omissions else []}

def validate_omissions(omissions,included):
 if not isinstance(omissions,list):raise ValueError('Invalid omission manifest')
 seen=set()
 for item in omissions:
  if not isinstance(item,dict) or set(item)!={'path','bytes','mtime_ns','reason','content_verified'}:raise ValueError('Invalid omission entry')
  name=item['path']
  if not isinstance(name,str) or not allowed(name) or not name.startswith('МАТЕРИАЛЫ/') or name in included or name in seen:raise ValueError('Unsafe or conflicting omission')
  if type(item['bytes']) is not int or item['bytes']<0 or type(item['mtime_ns']) is not int or item['mtime_ns']<0:raise ValueError('Invalid omitted material metadata')
  if item['reason'] not in ('material_file_over_32_mib','material_aggregate_budget') or item['content_verified'] is not False:raise ValueError('Invalid omission reason or verification claim')
  seen.add(name)
def digest(data):return sha(json_bytes({n:sha(b) for n,b in sorted(data.items())}))
@contextlib.contextmanager
def operation_lock(root,name='backup-operation.lock',wait_seconds=10):
 if name not in ('backup-operation.lock','state-operation.lock','watcher-lifetime.lock'):raise ValueError('Unknown internal lock')
 path=internal(root,'.runtime/'+name);path.parent.mkdir(parents=True,exist_ok=True)
 deadline=time.monotonic()+wait_seconds
 while True:
  try:
   descriptor=os.open(path,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
   os.write(descriptor,str(os.getpid()).encode());os.close(descriptor);break
  except FileExistsError:
   try:owner=int(path.read_text())
   except (OSError,ValueError):owner=None
   if owner is not None and not alive(owner):path.unlink();continue
   if time.monotonic()>deadline:raise RuntimeError('Backup is busy; retry after the active operation')
   time.sleep(.05)
 try:yield
 finally:
  if path.exists() and path.read_text()==str(os.getpid()):path.unlink()
def verify(archive):
 with zipfile.ZipFile(archive) as z:
  infos=z.infolist();names=[x.filename for x in infos]
  if len(names)!=len(set(names)):raise ValueError('Duplicate archive entries')
  if 'META/backup.json' not in names:raise ValueError('Backup manifest missing')
  if sum(x.file_size for x in infos)>600*1024*1024:raise ValueError('Expanded archive is too large')
  for i in infos:
   if (i.external_attr>>16)&0o170000==0o120000:raise ValueError('Archive symlink rejected')
   if i.filename!='META/backup.json' and not allowed(i.filename):raise ValueError('Unsafe archive member: '+i.filename)
  meta=json.loads(z.read('META/backup.json'))
  if meta.get('format')!=VERSION:raise ValueError('Unsupported backup format')
  if set(meta['files'])!=set(names)-{'META/backup.json'}:raise ValueError('Manifest coverage mismatch')
  validate_omissions(meta.get('omissions',[]),meta['files'])
  for name,item in meta['files'].items():
   data=z.read(name)
   if len(data)!=item['bytes'] or sha(data)!=item['sha256']:raise ValueError('Checksum mismatch: '+name)
  if digest({n:z.read(n) for n in meta['files']})!=meta['content_digest']:raise ValueError('Content digest mismatch')
 return meta
def _snapshot_locked(root,reason='manual',force=False):
 # Caller owns backup-operation.lock; required by daily check-and-create too.
 folder=internal(root,'.backups');folder.mkdir(exist_ok=True)
 for attempt in range(3):
  data,omissions=payload(root,True);content_digest=digest(data)
  again,again_omissions=payload(root,True)
  if content_digest==digest(again) and omissions==again_omissions:break
 else:raise RuntimeError('Workspace changed while reading; backup deferred')
 archives=sorted(x for x in folder.glob('school-*.zip') if ARCHIVE_NAME.fullmatch(x.name))
 valid=[];corrupt=[]
 for archive in archives:
  if linked(archive) or archive.resolve().parent!=folder.resolve():raise ValueError('Linked backup archive rejected')
  try:valid.append((archive,verify(archive)))
  except (ValueError,KeyError,TypeError,zipfile.BadZipFile,OSError,json.JSONDecodeError):corrupt.append(archive)
 def preserve_corrupt():
  if not corrupt:return
  quarantine=internal(root,'.backups/corrupt');quarantine.mkdir(exist_ok=True)
  for damaged in corrupt:
   if linked(damaged) or damaged.resolve().parent!=folder.resolve() or not ARCHIVE_NAME.fullmatch(damaged.name):raise ValueError('Unexpected quarantine target')
   # Preserve bytes rather than delete an old damaged copy. Never overwrite it.
   dest=quarantine/(damaged.name+'.'+uuid.uuid4().hex[:8]+'.damaged');damaged.replace(dest)
 if valid and not force and valid[-1][1]['content_digest']==content_digest and valid[-1][1].get('omissions',[])==omissions:
  preserve_corrupt()
  return {'created':False,'archive':str(valid[-1][0]),'verified':True,'files':len(data),'content_digest':content_digest,'damaged_copies_preserved':len(corrupt),**coverage(valid[-1][1])}
 meta={'format':VERSION,'created_at':now(),'reason':reason,'content_digest':content_digest,'files':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(data.items())},'omissions':omissions}
 name='school-'+stamp()+'-'+uuid.uuid4().hex[:6]+'.zip';final=folder/name;tmp=final.with_suffix('.partial')
 with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as z:
  for n,b in sorted(data.items()):z.writestr(n,b)
  z.writestr('META/backup.json',json_bytes(meta))
 verify(tmp);tmp.replace(final)
 preserve_corrupt()
 atomic_json(internal(root,'.runtime/last-backup.json'),{'archive':name,'created_at':meta['created_at'],'content_digest':content_digest,'verified':True,**coverage(meta)})
 # Keep the current and two prior verified snapshots; only our exact known files.
 archives=sorted(x for x in folder.glob('school-*.zip') if ARCHIVE_NAME.fullmatch(x.name))
 for old in archives[:-3]:
  if linked(old) or old.resolve().parent!=folder.resolve() or not ARCHIVE_NAME.fullmatch(old.name):raise ValueError('Unexpected rotation target')
  verify(old);old.unlink()
 return {'created':True,'archive':str(final),'verified':True,'files':len(data),'content_digest':content_digest,'damaged_copies_preserved':len(corrupt),**coverage(meta)}

def snapshot(root,reason='manual',force=False):
 root=Path(root).resolve()
 with operation_lock(root):
  return _snapshot_locked(root,reason,force)

def daily_day(value=None):
 """A checkpoint day follows the computer's local calendar, not a wake schedule."""
 if value is None:return datetime.now().astimezone().date().isoformat()
 if not isinstance(value,str):raise ValueError('Daily backup day must be ISO YYYY-MM-DD')
 try:parsed=date.fromisoformat(value)
 except ValueError:raise ValueError('Daily backup day must be ISO YYYY-MM-DD')
 if parsed.isoformat()!=value:raise ValueError('Daily backup day must be ISO YYYY-MM-DD')
 return value

def ensure_daily_snapshot(root,day=None):
 """Verify/reuse a local-day checkpoint, or create one atomically.

 This runs only when called (launch or a live watcher). It is not an OS scheduler
 and does not run while the computer is off. A rotated or corrupt checkpoint is
 not accepted as proof. Three verified archives remain the shared history.
 """
 root=Path(root).resolve();day=daily_day(day);reason='daily:'+day
 with operation_lock(root):
  folder=internal(root,'.backups')
  if folder.exists():
   for archive in sorted(folder.glob('school-*.zip'),reverse=True):
    if not ARCHIVE_NAME.fullmatch(archive.name):continue
    if linked(archive) or archive.resolve().parent!=folder.resolve():raise ValueError('Linked backup archive rejected')
    try:meta=verify(archive)
    except (ValueError,KeyError,TypeError,zipfile.BadZipFile,OSError,json.JSONDecodeError):continue
    if meta.get('reason')==reason:
     return {'created':False,'archive':str(archive),'verified':True,
      'files':len(meta['files']),'content_digest':meta['content_digest'],
      'daily_day':day,'daily_checkpoint':True,'calendar_basis':'computer_local_date',
      **coverage(meta)}
  result=_snapshot_locked(root,reason,force=True)
  return {**result,'daily_day':day,'daily_checkpoint':True,
   'calendar_basis':'computer_local_date'}

def restore(archive,target):
 meta=verify(archive);target=Path(target).absolute()
 if linked(target) or any(linked(p) for p in target.parents):raise ValueError('Linked restore target rejected')
 if target.exists() and (not target.is_dir() or any(target.iterdir())):raise ValueError('Restore target must be a new or empty directory')
 target.mkdir(parents=True,exist_ok=True);target=target.resolve()
 with zipfile.ZipFile(archive) as z:
  for name in meta['files']:
   dest=internal(target,name);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(name))
 for name,item in meta['files'].items():
  restored=internal(target,name)
  if restored.stat().st_size!=item['bytes'] or sha(restored.read_bytes())!=item['sha256']:raise ValueError('Restored files did not verify')
 atomic_json(internal(target,'.runtime/migration-receipt.json'),{'restored_at':now(),'files':len(meta['files']),'content_digest':meta['content_digest'],'verified':True,'source_archive_name':Path(archive).name,'learning_progress_retested':False,**coverage(meta)})
 return {'restored':True,'target':str(target),'files':len(meta['files']),'verified':True,'learning_progress_retested':False,**coverage(meta)}
def watch_status(root):
 path=internal(root,'.runtime/backup-watch.json')
 if not path.exists():return {'running':False,'reason':'not_started'}
 state=json.loads(path.read_text('utf-8'));fresh=time.time()-path.stat().st_mtime<=max(20,float(state.get('interval',60))*3)
 state['running']=state.get('status')=='running' and fresh and alive(state.get('pid'))
 return state
def watch(root,interval,run_id):
 root=Path(root).resolve();runtime=internal(root,'.runtime');runtime.mkdir(exist_ok=True)
 # The lifetime lock precedes the first expensive snapshot and all status writes.
 with operation_lock(root,'watcher-lifetime.lock',wait_seconds=0):
  path=runtime/'backup-watch.json';stop=runtime/'backup-stop.json'
  state={'run_id':run_id,'pid':os.getpid(),'interval':interval,'started_at':now(),'status':'running','last_error':None,'last_backup':None,'last_daily':None,'last_daily_error':None,'heartbeat_at':now()}
  atomic_json(path,state);due=0
  try:
   while True:
    if stop.exists():
     try:
      if json.loads(stop.read_text('utf-8')).get('run_id')==run_id:break
     except (ValueError,OSError):pass
    if time.monotonic()>=due:
     try:state['last_daily']=ensure_daily_snapshot(root);state['last_daily_error']=None
     except Exception as e:state['last_daily_error']=str(e)
     try:state['last_backup']=snapshot(root,'automatic');state['last_error']=None
     except Exception as e:state['last_error']=str(e)
     due=time.monotonic()+interval
    state['heartbeat_at']=now();atomic_json(path,state);time.sleep(.5)
  finally:state['status']='stopped';state['stopped_at']=now();atomic_json(path,state)
def start(root,interval):
 current=watch_status(root)
 if current.get('running'):return {**current,'already_running':True}
 root=Path(root).resolve();runtime=internal(root,'.runtime');runtime.mkdir(exist_ok=True);run_id=str(uuid.uuid4())
 log=open(runtime/'backup-watch.log','ab')
 kwargs={'creationflags':subprocess.CREATE_NO_WINDOW} if os.name=='nt' else {'start_new_session':True}
 env={**os.environ,'PYTHONIOENCODING':'utf-8','PYTHONUTF8':'1'}
 try:proc=subprocess.Popen([sys.executable,'-X','utf8',str(Path(__file__).resolve()),'watch','--root',str(root),'--interval',str(interval),'--run-id',run_id],cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=log,env=env,encoding='utf-8',errors='backslashreplace',**kwargs)
 finally:log.close()
 deadline=time.monotonic()+8
 while time.monotonic()<deadline:
  current=watch_status(root)
  if current.get('run_id')==run_id and current.get('running'):return current
  if proc.poll() is not None:
   if current.get('running'):return {**current,'already_running':True}
   raise RuntimeError('Backup watcher exited; inspect .runtime/backup-watch.log')
  time.sleep(.1)
 raise RuntimeError('Backup watcher readiness not confirmed')
def stop(root):
 current=watch_status(root)
 if not current.get('running'):return {**current,'stopped':True}
 atomic_json(internal(root,'.runtime/backup-stop.json'),{'run_id':current['run_id'],'requested_at':now()})
 deadline=time.monotonic()+8
 while time.monotonic()<deadline:
  if not watch_status(root).get('running'):return {'stopped':True,'run_id':current['run_id']}
  time.sleep(.1)
 raise RuntimeError('Stop requested; process has not confirmed stopping')
def main():
 configure_output()
 p=argparse.ArgumentParser();p.add_argument('action',choices=['create','verify','restore','export','start','stop','status','watch']);p.add_argument('--root',default=str(Path(__file__).resolve().parents[1]));p.add_argument('--archive');p.add_argument('--target');p.add_argument('--output');p.add_argument('--interval',type=float,default=60);p.add_argument('--run-id');a=p.parse_args();root=Path(a.root).resolve()
 try:
  if a.action=='create':result=snapshot(root)
  elif a.action=='verify':result={'verified':True,**verify(a.archive)}
  elif a.action=='restore':
   if not a.archive or not a.target:p.error('--archive and --target required')
   result=restore(a.archive,a.target)
  elif a.action=='export':
   if not a.output:p.error('--output required')
   result=snapshot(root,'migration-export',force=True);dest=Path(a.output).absolute()
   if dest.exists():raise ValueError('Export destination already exists; choose a new filename')
   if linked(dest) or any(linked(x) for x in dest.parents):raise ValueError('Linked export target rejected')
   dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(result['archive'],dest);verify(dest);result['exported_to']=str(dest)
  elif a.action=='start':
   if a.interval<1:p.error('--interval must be at least 1 second')
   result=start(root,a.interval)
  elif a.action=='stop':result=stop(root)
  elif a.action=='status':result=watch_status(root)
  else:
   if not a.run_id or a.interval<1:p.error('--run-id and interval >= 1 required')
   watch(root,a.interval,a.run_id);return
  print(json.dumps(result,ensure_ascii=False))
 except Exception as e:print(json.dumps({'ok':False,'error':str(e)},ensure_ascii=False));raise SystemExit(2)
if __name__=='__main__':main()
