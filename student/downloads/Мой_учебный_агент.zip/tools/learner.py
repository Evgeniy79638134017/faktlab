"""School agent state, launch evidence and stage gates. No model or network calls."""
from __future__ import annotations
import argparse,copy,hashlib,html,json,os,sys,uuid
from pathlib import Path
from datetime import datetime,timezone
import school_backup as backup
from progress_contract import validate_progression, record_template
from career_contract import validate_career_profile

STATE='ДАННЫЕ/состояние.json'
STAGES=('discovery','orientation','research','roadmap','practice')
PROVENANCE={'self_report','observed_in_session','imported_record'}
DOMAINS=('goals','interests','experience','study','materials','habits','resources','life_skills','future','support')
LESSONS={'task','context','attempt','hint','verify','materials','map','check','research','project','memory','backup','transfer','review','future','dialogue'}
def read(path):return json.loads(Path(path).read_text('utf-8-sig'))
def nonempty(x):return isinstance(x,str) and bool(x.strip())
def confirmed(x):return isinstance(x,dict) and x.get('confirmed') is True and nonempty(x.get('evidence'))
def unique(items,key='id'):
 ids=[x.get(key) for x in items];return all(nonempty(i) for i in ids) and len(ids)==len(set(ids))
def validate(s):
 e=[]
 def need(c,m):
  if not c:e.append(m)
 need(s.get('schema_version')=='school-agent-2.0','Unsupported state version')
 need(s.get('data_mode') in ('empty_profile','live_learner','synthetic_scenario'),'Unknown data mode')
 need(s.get('stage') in STAGES,'Unknown stage')
 need(isinstance(s.get('revision'),int) and s.get('revision',-1)>=0,'Invalid revision')
 for name in ('learner','discovery','orientation','research','roadmap','current_study','agent_learning'):
  need(isinstance(s.get(name),dict),'Missing object: '+name)
 for name in ('goals','sessions'):need(isinstance(s.get(name),list),'Missing list: '+name)
 if e:return e
 need(s['learner'].get('age_band') in ('not_stated','under_13','13_17','18_plus'),'Invalid age band')
 need(unique(s['goals']),'Goal IDs must be nonempty and unique')
 goalids={g.get('id') for g in s['goals']}
 for g in s['goals']:
  need(all(nonempty(g.get(k)) for k in ('title','why','baseline','success_criterion','horizon')),'Goal needs title, purpose, baseline, success criterion, horizon')
  need(g.get('provenance') in PROVENANCE,'Goal provenance missing')
 answers=s['discovery'].get('answers',[])
 need(isinstance(answers,list) and unique(answers),'Discovery answer IDs must be unique')
 for a in answers:
  need(a.get('domain') in DOMAINS,'Unknown discovery domain')
  need(nonempty(a.get('answer')) and nonempty(a.get('source')),'Answer needs content and source')
  need(a.get('provenance') in PROVENANCE,'Answer provenance missing')
 hypotheses=s['orientation'].get('hypotheses',[])
 observations=s['orientation'].get('observations',[])
 need(unique(observations),'Observation IDs must be unique')
 for observation in observations:
  need(nonempty(observation.get('evidence_summary')) and nonempty(observation.get('source')),'Orientation observation needs evidence and source')
  need(observation.get('provenance') in PROVENANCE|{'source_document','agent_hypothesis'},'Observation provenance missing')
 evidenceids={a.get('id') for a in answers}|{o.get('id') for o in observations}
 need(unique(hypotheses),'Hypothesis IDs must be unique')
 for h in hypotheses:
  need(h.get('provenance') in PROVENANCE|{'model_inference'},'Hypothesis provenance missing')
  need(nonempty(h.get('title')) and isinstance(h.get('evidence_ids'),list) and bool(h['evidence_ids']),'Hypothesis needs title and evidence')
  need(set(h.get('evidence_ids',[]))<=evidenceids,'Hypothesis references unknown evidence')
  need(nonempty(h.get('uncertainty')),'Hypothesis needs uncertainty')
 sources=s['research'].get('sources',[]);need(unique(sources),'Research source IDs must be unique');sourceids={x.get('id') for x in sources}
 for x in sources:
  need(x.get('status') in ('found','read','unavailable'),'Invalid source status')
  need(all(nonempty(x.get(k)) for k in ('title','location','kind')),'Source needs title, location, kind')
  if x.get('status')=='read':need(all(nonempty(x.get(k)) for k in ('checked_at','evidence','limitations')),'Read source needs date, evidence and limitations')
 for f in s['research'].get('findings',[]):
  need(set(f.get('source_ids',[]))<=sourceids and bool(f.get('source_ids')),'Research finding references unknown/no source')
  need(set(f.get('goal_ids',[]))<=goalids and bool(f.get('goal_ids')),'Finding must connect to known goals')
  need(nonempty(f.get('claim')) and nonempty(f.get('limits')),'Finding needs claim and limits')
 tasks=s['roadmap'].get('tasks',[]);need(unique(tasks),'Task IDs must be unique');taskids={t.get('id') for t in tasks}
 for t in tasks:
  need(t.get('goal_id') in goalids,'Task references unknown goal')
  need(all(nonempty(t.get(k)) for k in ('action','owner','when','done_when','verification','effort','risk')),'Task lacks action/owner/time/result/verification/effort/risk')
  need(isinstance(t.get('dependencies'),list) and set(t.get('dependencies',[]))<=taskids and t.get('id') not in t.get('dependencies',[]),'Invalid task dependencies')
  need(t.get('status') in ('planned','in_progress','done','paused'),'Invalid task status')
  if t.get('status')=='done':need(nonempty(t.get('result_evidence')) and t.get('result_provenance') in PROVENANCE,'Completed task needs actual evidence and provenance')
 graph={t['id']:t.get('dependencies',[]) for t in tasks if nonempty(t.get('id'))};visiting=set();seen=set()
 def cycle(k):
  if k in visiting:return True
  if k in seen or k not in graph:return False
  visiting.add(k)
  if any(cycle(x) for x in graph[k]):return True
  visiting.remove(k);seen.add(k);return False
 need(not any(cycle(k) for k in graph),'Roadmap contains a dependency cycle')
 try:
  from study_validate import validate_current_study
  e.extend('study: '+x for x in validate_current_study(s['current_study'],sessions=s['sessions'],data_mode=s['data_mode']))
 except ImportError:need(False,'Current-study validator is missing')
 e.extend('progression: '+x for x in validate_progression(s))
 e.extend(validate_career_profile(s))
 for session in s['sessions']:
  need(unique(s['sessions']),'Session IDs must be unique')
  need(all(nonempty(session.get(k)) for k in ('id','date','learner_action','help_given','not_verified','next_step')),'Session needs action/help/unknowns/next step')
  need(session.get('provenance') in PROVENANCE,'Session provenance missing')
 lessons=s['agent_learning'].get('lessons',[])
 need(isinstance(lessons,list) and unique(lessons),'Agent lesson IDs must be unique')
 for lesson in lessons:
  need(lesson.get('id') in LESSONS,'Unknown agent lesson ID; use ОБУЧЕНИЕ_АГЕНТУ/УРОКИ.json')
  need(lesson.get('status') in ('offered','practiced_with_help','demonstrated','revisit'),'Unknown agent lesson status')
  need(all(nonempty(lesson.get(k)) for k in ('learner_action','help_given','evidence')),'Agent lesson needs actual action, help and evidence')
  need(lesson.get('provenance') in PROVENANCE,'Agent lesson provenance missing')
 return e
def gate(s,target):
 e=[]
 def need(c,m):
  if not c:e.append(m)
 if target not in STAGES:return ['Unknown target stage']
 index=STAGES.index(target)
 if index>=1:
  d=s['discovery'];coverage=d.get('coverage',{})
  for domain in DOMAINS:
   x=coverage.get(domain,{})
   need(x.get('status') in ('discussed','not_needed','deferred') and nonempty(x.get('summary')),'Discovery domain needs substantive status and summary: '+domain)
   if x.get('status')=='discussed':need(bool(x.get('answer_ids')) and set(x.get('answer_ids',[]))<={a['id'] for a in d.get('answers',[]) if a.get('domain')==domain},'Coverage must reference answers in its own domain: '+domain)
   else:need(nonempty(x.get('reason')),'Deferred/not-needed domain needs reason: '+domain)
  need(confirmed(d.get('summary_confirmation')),'Learner has not confirmed discovery summary')
  need(bool(s['goals']) and all(confirmed(g.get('confirmation')) for g in s['goals']),'Need learner-confirmed goals')
  need(not d.get('critical_gaps'),'Critical discovery gaps remain')
 if index>=2:
  o=s['orientation'];need(2<=len(o.get('hypotheses',[]))<=3,'Need 2–3 orientation hypotheses')
  for h in o.get('hypotheses',[]):
   probe=h.get('probe',{});need(all(nonempty(probe.get(k)) for k in ('action','timebox','observation','success_criterion')),'Hypothesis needs a concrete safe probe')
  selected=o.get('selected_hypothesis_ids',[])
  need(bool(selected) and set(selected)<={h['id'] for h in o.get('hypotheses',[])},'Learner needs to select a hypothesis for research')
  need(confirmed(o.get('confirmation')),'Orientation choice is not confirmed')
 if index>=3:
  r=s['research'];read_sources=[x for x in r.get('sources',[]) if x.get('status')=='read']
  need(bool(r.get('questions')),'Research questions missing');need(bool(read_sources),'No actually read sources')
  need(bool(r.get('findings')),'Research findings missing');need(len(r.get('options',[]))>=2,'Need at least two compared routes')
  for finding in r.get('findings',[]):need(set(finding.get('source_ids',[]))<={x['id'] for x in read_sources},'Completed research finding must reference actually read sources')
  for option in r.get('options',[]):
   need(all(nonempty(option.get(k)) for k in ('id','title','entry_requirements','time_and_cost','next_probe','limits')),'Route comparison lacks entry/time/cost/probe/limits')
   need(bool(option.get('source_ids')) and set(option.get('source_ids',[]))<={x['id'] for x in read_sources},'Route must reference read sources')
  need(not r.get('critical_gaps'),'Research critical gaps remain; partial report is allowed, completion is not')
  need(confirmed(r.get('scope_confirmation')),'Research scope/result confirmation missing')
 if index>=4:
  need(bool(s['roadmap'].get('tasks')),'Roadmap has no actions');need(confirmed(s['roadmap'].get('confirmation')),'Learner has not accepted roadmap')
  goals={t.get('goal_id') for t in s['roadmap'].get('tasks',[])};need(goals>={g['id'] for g in s['goals']},'A goal has no roadmap action')
 return e
def validate_for_stage(s):
 e=validate(s)
 if not e:e.extend(gate(s,s['stage']))
 return e
def revise(s,target,reason):
 if not nonempty(reason):raise ValueError('Revision needs an explicit reason from the conversation')
 if target not in STAGES or STAGES.index(target)>STAGES.index(s['stage']):raise ValueError('Revision must use the current or an earlier stage')
 result=copy.deepcopy(s);index=STAGES.index(target)
 result.setdefault('revision_events',[]).append({'from':s['stage'],'to':target,'reason':reason,'at':backup.now(),'previous_revision':s['revision']})
 pending={'confirmed':False,'evidence':''}
 if index==0:
  result['discovery']['summary_confirmation']=copy.deepcopy(pending)
  for goal in result['goals']:goal['confirmation']=copy.deepcopy(pending)
 if index<=1:result['orientation']['confirmation']=copy.deepcopy(pending)
 if index<=2:result['research']['scope_confirmation']=copy.deepcopy(pending)
 result['roadmap']['confirmation']=copy.deepcopy(pending)
 for task in result['roadmap'].get('tasks',[]):
  if task.get('status') in ('planned','in_progress'):
   task['status']='paused';task['pause_reason']='Пересмотр маршрута: '+reason
 progression=result.get('progression',{})
 for scenario in progression.get('future_scenarios',[]):
  if scenario.get('target_status')=='chosen':scenario.update(target_status='draft',confirmed_by_learner=False)
 for name in ('milestones','projects','trials'):
  for item in progression.get(name,[]):
   if item.get('status') in ('planned','in_progress','suggested'):item['status']='paused'
 result['stage']=target
 result['next_step']='Уточнить изменившееся: '+reason+'; сверить связанные выводы и действия с учеником.'
 return result
def save(root,s):
 root=Path(root).resolve();path=backup.internal(root,STATE)
 with backup.operation_lock(root,'state-operation.lock'):
  old=read(path)
  if s.get('revision')!=old.get('revision'):raise ValueError('Revision conflict: reread state; do not overwrite a newer session')
  problems=validate_for_stage(s)
  if problems:raise ValueError('; '.join(problems))
  before=backup.snapshot(root,'before-state-change');s=copy.deepcopy(s);s['revision']+=1;s['updated_at']=backup.now()
  history=backup.internal(root,'ДАННЫЕ/_Версии');history.mkdir(parents=True,exist_ok=True)
  first=history/'состояние.previous.json';second=history/'состояние.previous2.json'
  if first.exists():second.write_bytes(first.read_bytes())
  first.write_bytes(path.read_bytes());backup.atomic_json(path,s)
  if read(path)!=s:raise RuntimeError('State readback failed')
  after=backup.snapshot(root,'after-state-change')
  return {'saved':True,'revision':s['revision'],'stage':s['stage'],'backup_before':before['verified'],'backup_after':after['verified'],**backup_summary(after)}

def backup_summary(shot):
 return {'backup_complete':not shot['partial'],'omitted_count':len(shot['omissions']),'backup_omissions':shot['omissions'],'warning_codes':shot['warning_codes'][:]}

def session_template(session_id,date):
 if not nonempty(session_id) or not nonempty(date):raise ValueError('--session-id and --date are required')
 if datetime.strptime(date,'%Y-%m-%d').strftime('%Y-%m-%d')!=date:raise ValueError('Use date YYYY-MM-DD')
 # Deliberately incomplete: only the agent reading the actual dialogue may fill
 # these fields. No evidence, successful result or provenance is invented here.
 return {'id':session_id,'date':date,'learner_action':'','help_given':'','not_verified':'','next_step':'','source':'','provenance':None}

def launch(root,watch=True):
 root=Path(root).resolve();manifest=read(root/'МАНИФЕСТ.json');errors=[];checked=0
 required={'AGENTS.md','НАЧАТЬ.md','РОЛЬ_АГЕНТА.md',STATE,'ДАННЫЕ/ВОПРОСЫ.json','tools/learner.py','tools/school_backup.py','tools/study_validate.py','ОБУЧЕНИЕ_АГЕНТУ/УРОКИ.json'}
 required.update('.agents/skills/'+n+'/SKILL.md' for n in ('learner-start','learner-discovery','agent-literacy','career-exploration','learner-research','learner-roadmap','daily-coach','learner-portable','study-session','study-source','study-check','study-state','study-plan','study-map','study-notebook-bridge'))
 required.update(('tools/progress_contract.py','tools/progress_dashboard.py','.agents/skills/learner-dashboard/SKILL.md'))
 if not isinstance(manifest.get('files'),dict) or not required<=set(manifest['files']):raise ValueError('Manifest omits required school-agent components')
 if not isinstance(manifest.get('package_version'),str) or not manifest['package_version'].startswith('school-agent-'):raise ValueError('Unknown package identity')
 mutable={'ДАННЫЕ/состояние.json','СОСТОЯНИЕ.md','ChatGPT/состояние.json'}
 for name,item in manifest['files'].items():
  path=backup.internal(root,name)
  if item.get('mutable') and name not in mutable:errors.append('Unexpected mutable distribution file: '+name)
  if not path.is_file():errors.append('Missing file: '+name)
  elif not item.get('mutable') and backup.sha(path.read_bytes())!=item['sha256']:errors.append('Changed distribution file: '+name)
  else:checked+=1
 if errors:raise ValueError('; '.join(errors))
 problems=validate_for_stage(read(root/STATE))
 if problems:raise ValueError('; '.join(problems))
 runtime=backup.internal(root,'.runtime');runtime.mkdir(exist_ok=True);canary=runtime/('write-check-'+uuid.uuid4().hex+'.txt');text='read-write-check '+str(uuid.uuid4());canary.write_text(text,'utf-8')
 if canary.read_text('utf-8')!=text:raise RuntimeError('Write/read check failed')
 canary.unlink();daily=backup.ensure_daily_snapshot(root);shot=backup.snapshot(root,'first-launch');warnings=[]
 watcher={'running':False,'reason':'disabled_for_this_check'}
 if watch:
  try:watcher=backup.start(root,60)
  except (OSError,RuntimeError) as error:
   watcher={'running':False,'reason':'start_unavailable'}
   warnings.append({'code':'BACKGROUND_BACKUP_UNAVAILABLE','message':str(error)})
 result={'format':'school-launch-receipt-1.0','checked_at':backup.now(),'workspace':str(root),'package_version':manifest['package_version'],'checked_files':checked,'read_write_verified':True,'backup_verified':shot['verified'],'watcher_running':watcher.get('running',False),'python':sys.version.split()[0],'model_behavior_tested':False,'learner_progress_verified':False}
 result.update(backup_summary(shot));result['warnings']=warnings;result['watcher_reason']=watcher.get('reason')
 result['daily_backup_verified']=bool(daily.get('verified'));result['daily_backup_day']=daily.get('daily_day');result['daily_backup']=daily
 result['warning_codes'].extend(item['code'] for item in warnings)
 backup.atomic_json(runtime/'launch-receipt.json',result);return result
def dashboard(root):
 root=Path(root).resolve()
 errors=validate_for_stage(read(root/STATE))
 if errors:raise ValueError('; '.join(errors))
 from progress_dashboard import render
 return render(root)
def main():
 backup.configure_output()
 p=argparse.ArgumentParser();p.add_argument('action',choices=['status','validate','launch','save','advance','revise','dashboard','session-template','progress-template']);p.add_argument('--root',default=str(Path(__file__).resolve().parents[1]));p.add_argument('--file');p.add_argument('--next',choices=STAGES);p.add_argument('--reason');p.add_argument('--no-watch',action='store_true');p.add_argument('--session-id');p.add_argument('--date');p.add_argument('--kind');a=p.parse_args();root=Path(a.root).resolve()
 try:
  if a.action=='session-template':
   print(json.dumps(session_template(a.session_id,a.date),ensure_ascii=False));return
  if a.action=='progress-template':
   print(json.dumps(record_template(a.kind),ensure_ascii=False));return
  s=read(root/STATE)
  if a.action=='status':result={'stage':s['stage'],'revision':s['revision'],'next_step':s['next_step'],'study_available':True,'backup':backup.watch_status(root)}
  elif a.action=='validate':
   errors=validate_for_stage(s);result={'valid':not errors,'errors':errors}
   if errors:print(json.dumps(result,ensure_ascii=False));raise SystemExit(2)
  elif a.action=='launch':result=launch(root,not a.no_watch)
  elif a.action=='save':
   if not a.file:p.error('--file required')
   candidate=read(a.file)
   if candidate.get('stage')!=s['stage']:raise ValueError('Use advance for stage transitions')
   result=save(root,candidate)
  elif a.action=='revise':
   if not a.next or not a.reason:p.error('--next and --reason required')
   result=save(root,revise(s,a.next,a.reason))
  elif a.action=='advance':
   if not a.next:p.error('--next required')
   if STAGES.index(a.next)!=STAGES.index(s['stage'])+1:raise ValueError('Only the next stage can be entered')
   errors=gate(s,a.next)
   if errors:raise ValueError('; '.join(errors))
   s['stage']=a.next;result=save(root,s)
  else:result=dashboard(root)
  print(json.dumps(result,ensure_ascii=False))
 except Exception as e:print(json.dumps({'ok':False,'error':str(e)},ensure_ascii=False));raise SystemExit(2)
if __name__=='__main__':main()
