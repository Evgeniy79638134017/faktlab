"""Optional portable progression graph. Pure validation; no I/O or model calls.

Completion records describe evidence with explicit provenance. Validation cannot
prove that free text is truthful and never grants academic mastery. Support roles
are roles of one assistant, not autonomous agents. Old states need no migration.
"""
from __future__ import annotations

import copy
from datetime import date
import ipaddress
import math
import re
from urllib.parse import parse_qsl, urlsplit

SCHEMA_VERSION = 'learner-progression-1.0'
TABLES = ('future_scenarios', 'milestones', 'projects', 'trials', 'balance', 'communities')
SUPPORT_ROLES = frozenset(('study_mentor', 'career_navigator', 'project_mentor', 'planner', 'reflection_coach'))
PROVENANCE = frozenset(('self_report', 'observed_in_session', 'imported_record', 'agent_hypothesis', 'source_document'))
HUMAN_EVIDENCE = frozenset(('self_report', 'observed_in_session'))
ACTION_STATUSES = frozenset(('planned', 'in_progress', 'done', 'paused'))

# Templates deliberately cannot validate until filled from an actual source.
_TEMPLATES = {
    'future_scenarios': {'id': '', 'goal_id': '', 'title': '', 'target_age': None,
        'target_status': None, 'assumptions': [], 'confirmed_by_learner': False,
        'source': '', 'provenance': None},
    'milestones': {'id': '', 'scenario_id': '', 'goal_id': '', 'title': '',
        'age_from': None, 'age_to': None, 'success_criterion': '', 'task_ids': [],
        'topic_ids': [], 'trial_ids': [], 'support_role_ids': [], 'status': None,
        'source': '', 'provenance': None},
    'projects': {'id': '', 'goal_id': '', 'title': '', 'task_ids': [],
        'status': None, 'source': '', 'provenance': None},
    'trials': {'id': '', 'hypothesis_id': '', 'goal_id': '', 'title': '',
        'question': '', 'action': '', 'when': '', 'status': None, 'source': '', 'provenance': None},
    'balance': {'id': '', 'domain': '', 'score': None, 'recorded_on': '', 'source': '', 'provenance': None},
    'communities': {'id': '', 'title': '', 'url': '', 'goal_ids': [],
        'milestone_ids': [], 'status': None, 'source': '', 'provenance': None},
}
_OPTIONAL = {'future_scenarios': {'target_age'},
    'milestones': {'age_from', 'age_to', 'result_evidence'},
    'projects': {'result_evidence'}, 'trials': {'result_evidence', 'reflection'},
    'balance': set(), 'communities': {'evidence'}}
_ALIASES = {'future_scenario': 'future_scenarios', 'milestone': 'milestones',
    'project': 'projects', 'trial': 'trials', 'community': 'communities'}


def empty_progression():
    """Return a fresh valid empty branch; never modify the supplied state."""
    return {'schema_version': SCHEMA_VERSION, **{name: [] for name in TABLES}}


def record_template(kind):
    """Blank record, not evidence or a persisted update. Singular/plural accepted."""
    kind = _ALIASES.get(kind, kind) if isinstance(kind, str) else None
    if kind not in _TEMPLATES:
        raise ValueError('Unknown progression record kind')
    return copy.deepcopy(_TEMPLATES[kind])


def _text(value):
    return isinstance(value, str) and bool(value.strip()) and not any(
        ord(c) < 32 and c not in '\n\r\t' for c in value)


def _identifier(value):
    return _text(value) and value == value.strip() and len(value) <= 128 and not any(c.isspace() for c in value)


def _enum(value, values):
    return isinstance(value, str) and value in values


def safe_community_url(value):
    """Validate a public HTTP(S) link syntactically, without DNS/network access."""
    if not isinstance(value, str) or not value or len(value) > 2048:
        return False
    if any(c.isspace() or ord(c) < 32 or ord(c) == 127 for c in value) or any(c in value for c in '\\<>"\'`'):
        return False
    try:
        parsed = urlsplit(value)
        if parsed.scheme not in ('https', 'http') or not parsed.netloc or not parsed.hostname:
            return False
        if parsed.username is not None or parsed.password is not None:
            return False
        if parsed.port is not None and not 1 <= parsed.port <= 65535:
            return False
        host = parsed.hostname.lower().rstrip('.')
        if '%' in host or host in ('localhost', 'localhost.localdomain') or host.endswith(('.localhost', '.local', '.internal')):
            return False
        try:
            if not ipaddress.ip_address(host).is_global:
                return False
        except ValueError:
            # Reject alternate numeric hosts and require a plausible DNS name.
            if '.' not in host or re.fullmatch(r'[0-9.]+', host):
                return False
            encoded = host.encode('idna').decode('ascii')
            labels = encoded.split('.')
            if len(encoded) > 253 or any(not re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?', s) for s in labels):
                return False
            if labels[-1].isdigit():
                return False
        sensitive = {'token', 'access_token', 'api_key', 'apikey', 'password', 'secret', 'session'}
        if any(key.lower() in sensitive for key, _ in parse_qsl(parsed.query)):
            return False
        return True
    except (ValueError, UnicodeError):
        return False


def validate_progression(state):
    """Return precise errors without mutation. This is not a full JSON Schema engine."""
    if not isinstance(state, dict):
        return ['state: expected object']
    if 'progression' not in state:
        return []
    branch = state['progression']
    if not isinstance(branch, dict):
        return ['progression: expected object']
    errors = []

    def need(condition, message):
        if not condition:
            errors.append(message)

    need(branch.get('schema_version') == SCHEMA_VERSION, 'progression.schema_version: unsupported version')
    need(set(branch) == {'schema_version', *TABLES}, 'progression: exactly schema_version and six tables are required')
    maps = {}
    all_ids = set()
    for name in TABLES:
        table = branch.get(name)
        if not isinstance(table, list):
            errors.append('progression.' + name + ': expected array')
            table = []
        maps[name] = {}
        required = set(_TEMPLATES[name]) - _OPTIONAL[name]
        allowed = set(_TEMPLATES[name]) | _OPTIONAL[name]
        for index, item in enumerate(table):
            where = f'progression.{name}[{index}]'
            if not isinstance(item, dict):
                errors.append(where + ': expected object')
                continue
            need(required <= set(item), where + ': missing required fields')
            need(set(item) <= allowed, where + ': unknown fields')
            identifier = item.get('id')
            if not _identifier(identifier):
                errors.append(where + '.id: expected nonempty identifier')
                continue
            need(identifier not in all_ids, where + '.id: duplicate progression ID')
            all_ids.add(identifier)
            maps[name][identifier] = item

    def core_map(container, key, label):
        value = container.get(key) if isinstance(container, dict) else None
        if not isinstance(value, list):
            errors.append(label + ': expected referenced core array')
            return {}
        result = {}
        for item in value:
            if not isinstance(item, dict) or not _identifier(item.get('id')):
                errors.append(label + ': invalid referenced core ID')
                continue
            need(item['id'] not in result, label + ': duplicate referenced core ID')
            result[item['id']] = item
        return result

    goals = core_map(state, 'goals', 'goals')
    tasks = core_map(state.get('roadmap'), 'tasks', 'roadmap.tasks')
    topics = core_map(state.get('current_study'), 'topics', 'current_study.topics')
    hypotheses = core_map(state.get('orientation'), 'hypotheses', 'orientation.hypotheses')

    def reference(item, key, target, where):
        value = item.get(key)
        valid = _identifier(value) and value in target
        need(valid, where + '.' + key + ': unknown reference')
        return target.get(value) if valid else None

    def references(item, key, target, where):
        values = item.get(key)
        if not isinstance(values, list):
            errors.append(where + '.' + key + ': expected array of IDs')
            return []
        seen = set()
        result = []
        for value in values:
            if not _identifier(value):
                errors.append(where + '.' + key + ': invalid ID')
                continue
            need(value not in seen, where + '.' + key + ': duplicate reference')
            seen.add(value)
            need(value in target, where + '.' + key + ': unknown reference ' + value)
            if value in target:
                result.append(value)
        return result

    def age(item, field, where):
        value = item.get(field)
        need(value is None or (type(value) is int and 1 <= value <= 120), where + '.' + field + ': expected integer age 1..120 or null')

    for name, items in maps.items():
        for identifier, item in items.items():
            where = 'progression.' + name + '.' + identifier
            need(_text(item.get('source')), where + '.source: explicit source required')
            need(_enum(item.get('provenance'), PROVENANCE), where + '.provenance: unknown provenance')
            for key in ('title', 'success_criterion', 'question', 'action', 'when', 'domain', 'result_evidence', 'reflection', 'evidence'):
                if key in item:
                    need(_text(item[key]), where + '.' + key + ': nonempty text required')
            if name in ('future_scenarios', 'milestones', 'projects', 'trials'):
                reference(item, 'goal_id', goals, where)
            if name in ('milestones', 'projects', 'trials'):
                statuses = ACTION_STATUSES | {'suggested'} if name == 'trials' else ACTION_STATUSES
                need(_enum(item.get('status'), statuses), where + '.status: invalid action status')
                if item.get('status') == 'done':
                    need(_text(item.get('result_evidence')), where + ': done needs result_evidence')
                    need(_enum(item.get('provenance'), HUMAN_EVIDENCE), where + ': done needs explicit self_report or observed_in_session; an imported/model claim is insufficient')
            if name in ('milestones', 'projects'):
                task_ids = references(item, 'task_ids', tasks, where)
                for task_id in task_ids:
                    need(tasks[task_id].get('goal_id') == item.get('goal_id'), where + '.task_ids: task belongs to another goal')
            if name == 'future_scenarios':
                age(item, 'target_age', where)
                need(_enum(item.get('target_status'), {'draft', 'chosen', 'paused'}), where + '.target_status: invalid scenario status')
                need(type(item.get('confirmed_by_learner')) is bool, where + '.confirmed_by_learner: expected boolean')
                assumptions = item.get('assumptions')
                need(isinstance(assumptions, list) and all(_text(x) for x in assumptions), where + '.assumptions: expected array of nonempty text')
                if item.get('target_status') == 'chosen':
                    need(item.get('confirmed_by_learner') is True, where + ': chosen scenario requires learner confirmation')
                if item.get('confirmed_by_learner') is True:
                    need(_enum(item.get('provenance'), HUMAN_EVIDENCE), where + ': model/imported/source proposal cannot assert learner confirmation')
            elif name == 'milestones':
                scenario = reference(item, 'scenario_id', maps['future_scenarios'], where)
                if scenario is not None:
                    need(scenario.get('goal_id') == item.get('goal_id'), where + ': scenario belongs to another goal')
                age(item, 'age_from', where);age(item, 'age_to', where)
                if type(item.get('age_from')) is int and type(item.get('age_to')) is int:
                    need(item['age_from'] <= item['age_to'], where + ': age_from exceeds age_to')
                references(item, 'topic_ids', topics, where)
                for trial_id in references(item, 'trial_ids', maps['trials'], where):
                    need(maps['trials'][trial_id].get('goal_id') == item.get('goal_id'), where + ': trial belongs to another goal')
                references(item, 'support_role_ids', SUPPORT_ROLES, where)
            elif name == 'trials':
                reference(item, 'hypothesis_id', hypotheses, where)
            elif name == 'balance':
                score = item.get('score')
                need(type(score) in (int, float) and 0 <= score <= 10 and math.isfinite(score), where + '.score: finite number 0..10 required; boolean is not a score')
                need(item.get('provenance') == 'self_report', where + ': balance must be learner self_report, not an AI assessment')
                day = item.get('recorded_on')
                valid_date = False
                if isinstance(day, str) and re.fullmatch(r'\d{4}-\d{2}-\d{2}', day):
                    try:
                        valid_date = date.fromisoformat(day).isoformat() == day
                    except ValueError:
                        pass
                need(valid_date, where + '.recorded_on: valid ISO date YYYY-MM-DD required')
            elif name == 'communities':
                need(safe_community_url(item.get('url')), where + '.url: public HTTP(S) URL without credentials or secret query required')
                goal_ids = references(item, 'goal_ids', goals, where)
                for milestone_id in references(item, 'milestone_ids', maps['milestones'], where):
                    need(maps['milestones'][milestone_id].get('goal_id') in goal_ids, where + ': milestone goal must appear in goal_ids')
                need(_enum(item.get('status'), {'suggested', 'checked', 'joined'}), where + '.status: invalid community status')
                if item.get('status') in ('checked', 'joined'):
                    need(_text(item.get('evidence')), where + ': checked/joined needs evidence')
                    allowed_provenance = HUMAN_EVIDENCE if item.get('status') == 'joined' else HUMAN_EVIDENCE | {'source_document'}
                    need(_enum(item.get('provenance'), allowed_provenance), where + ': checked/joined needs direct evidence, not an imported/model assertion')
    return errors
