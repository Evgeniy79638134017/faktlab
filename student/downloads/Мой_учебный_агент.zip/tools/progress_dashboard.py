"""Portable read-only projection of canonical learner state. Standard library only.

render_html(state) has no I/O or clock dependency. render(root) validates progression
and writes only the current HTML and two prior HTML versions, never learner data.
"""
from __future__ import annotations
import contextlib
from datetime import date, datetime, timezone
import hashlib
import html
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import time
from urllib.parse import parse_qsl, quote, urlsplit
import uuid

OUTPUT = 'ЦЕЛИ/Личная_панель.html'
HISTORY = 'ЦЕЛИ/_Версии/Личная_панель'
ROLES = {
 'study_mentor': ('Учебный наставник', 'Разобраться в теме и проверить собственную попытку.'),
 'career_navigator': ('Навигатор направлений', 'Исследовать интересы через гипотезы и небольшие пробы.'),
 'project_mentor': ('Наставник проекта', 'Связать замысел со своим результатом и критерием готовности.'),
 'planner': ('Планировщик', 'Разложить выбранную цель на вехи и посильные действия.'),
 'reflection_coach': ('Помощник рефлексии', 'Отделить своё действие, помощь и то, что ещё не проверено.'),
}
ORIGINS = {'self_report': 'Со слов учащегося', 'observed_in_session': 'Наблюдалось в сессии',
 'imported_record': 'Импортированная запись', 'source_document': 'Из документа',
 'agent_hypothesis': 'Гипотеза агента', 'model_inference': 'Вывод агента'}
STATUSES = {'draft': 'Черновик', 'chosen': 'Выбран учащимся', 'planned': 'Запланировано',
 'in_progress': 'В работе', 'done': 'Завершение записано', 'paused': 'Приостановлено',
 'suggested': 'Предложено', 'checked': 'Проверка записана', 'joined': 'Участие записано',
 'not_started': 'Ещё не начато', 'needs_help': 'Нужна помощь', 'independent_once': 'Самостоятельно на одной проверке',
 'retained_on_checked_tasks': 'Удержание на проверенных задачах', 'not_checked': 'Не проверено',
 'pass': 'Проверка пройдена', 'partial': 'Частично', 'active': 'Актуально',
 'learner_reports_complete': 'Учащийся сообщил о завершении', 'reviewed_locally': 'Разобрано в проекте',
 'correct': 'Ответ верен', 'partly_correct': 'Ответ частично верен', 'incorrect': 'В ответе ошибка'}
ASSISTANCE = {'none': 'Без подсказки', 'minimal_hint': 'Короткая подсказка', 'scaffold': 'С опорой',
 'worked_example': 'После разобранного примера', 'answer_exposed': 'Ответ был показан'}
STAGES = {'discovery': 'Знакомство', 'orientation': 'Гипотезы направлений', 'research': 'Исследование',
 'roadmap': 'Маршрут', 'practice': 'Практика'}

# Explicit allowlist. Unknown fields, verifier_only and answer keys are never
# serialized into HTML, attributes, scripts, hidden nodes or a JSON payload.
FIELDS = {
 'goals': 'id title why baseline success_criterion horizon provenance confirmation',
 'hypotheses': 'id title evidence_ids uncertainty provenance probe',
 'observations': 'id evidence_summary source provenance',
 'answers': 'id domain answer source provenance',
 'subjects': 'id name level_label topic_ids resource_ids teacher_ai_rules ai_rules_note provenance',
 'resources': 'id title authors edition year access_status local_file public_url checked_on provenance',
 'topics': 'id title subject_id parent_topic_id prerequisite_topic_ids learning_outcomes status evidence_check_ids provenance',
 'study_goals': 'id description subject_id topic_ids success_criterion status evidence_check_ids provenance',
 'attempts': 'id session_id assignment_id topic_ids prompt learner_response response_format assistance feedback result provenance',
 'checks': 'id session_id topic_ids gap_ids attempt_id kind task_new_to_learner answer_seen_before assistance rubric outcome elapsed_days_since_learning provenance',
 'tasks': 'id goal_id action owner when done_when verification effort risk dependencies status result_evidence result_provenance',
 'sessions': 'id date learner_action help_given not_verified next_step provenance summary goal_ids subject_ids attempt_ids check_ids',
 'future_scenarios': 'id goal_id title target_age target_status assumptions confirmed_by_learner source provenance',
 'milestones': 'id scenario_id goal_id title age_from age_to success_criterion task_ids topic_ids trial_ids support_role_ids status source provenance result_evidence',
 'projects': 'id goal_id title task_ids status source provenance result_evidence',
 'trials': 'id hypothesis_id goal_id title question action when status source provenance result_evidence reflection',
 'balance': 'id domain score recorded_on source provenance',
 'communities': 'id title url goal_ids milestone_ids status source provenance evidence',
}
NESTED = {'provenance': {'kind','recorded_on','session_id','evidence_ref','confirmed_by_learner'},
 'confirmation': {'confirmed','evidence'}, 'probe': {'action','timebox','observation','success_criterion'}}


def _scalar(value):
 if isinstance(value,str): return value
 if value is None or type(value) in (bool,int): return value
 if type(value) is float and math.isfinite(value): return value
 return None


def _project_row(row,kind):
 out={}
 for key in FIELDS[kind].split():
  value=row.get(key)
  if key in NESTED and isinstance(value,dict):out[key]={k:_scalar(v) for k,v in value.items() if k in NESTED[key]}
  elif isinstance(value,list):out[key]=[v for v in value if isinstance(v,str)]
  else:out[key]=_scalar(value)
 return out


def _projection(state):
 state=state if isinstance(state,dict) else {}
 obj=lambda key:state.get(key) if isinstance(state.get(key),dict) else {}
 study=obj('current_study');progression=obj('progression');orientation=obj('orientation')
 raw={'goals':state.get('goals'),'hypotheses':orientation.get('hypotheses'),
  'observations':orientation.get('observations'),'answers':obj('discovery').get('answers'),
  'tasks':obj('roadmap').get('tasks'),'sessions':state.get('sessions'),'study_goals':study.get('goals')}
 for name in ('subjects','resources','topics','attempts','checks'):raw[name]=study.get(name)
 for name in ('future_scenarios','milestones','projects','trials','balance','communities'):raw[name]=progression.get(name)
 out={name:[_project_row(row,name) for row in rows if isinstance(row,dict)] if isinstance(rows,list) else [] for name,rows in raw.items()}
 out.update({key:_scalar(state.get(key)) for key in ('revision','updated_at','stage','data_mode','next_step')})
 out['next_action']=_scalar(study.get('next_action'));out['nickname']=_scalar(obj('learner').get('nickname_optional'))
 return out


def _text(value):
 if isinstance(value,str):return value
 if type(value) is bool:return 'да' if value else 'нет'
 if type(value) in (int,float) and math.isfinite(value):return str(value)
 return ''


def _h(value):return html.escape(_text(value),quote=True)
def _token(kind,value):return kind+'-'+hashlib.sha256(_text(value).encode('utf-8')).hexdigest()[:20]
def _array(value):return value if isinstance(value,list) else []
def _empty(message='Пока нет данных'):return '<p class="empty">'+_h(message)+'</p>'
def _para(value):return '<p class="body-text">'+_h(value)+'</p>' if _text(value) else ''


def _sibling(name):
 try:return __import__(name)
 except ImportError:
  path=Path(__file__).with_name(name+'.py')
  if not path.is_file():return None
  spec=importlib.util.spec_from_file_location('_dashboard_'+name,path)
  module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
  return module


def _internal(root,rel,backup=None):
 if backup is not None:return backup.internal(root,rel)
 root=Path(root).resolve();target=root/rel
 for part in [target,*target.parents]:
  if part==root:break
  if part.is_symlink():raise ValueError('Linked dashboard path is not allowed')
  try:
   if getattr(part.stat(follow_symlinks=False),'st_file_attributes',0)&1024:raise ValueError('Reparse dashboard path is not allowed')
  except FileNotFoundError:pass
 if not target.resolve().is_relative_to(root):raise ValueError('Dashboard path leaves workspace')
 return target


def _safe_link(value,root=None):
 if not isinstance(value,str) or not value or len(value)>2048:return None
 if any(ord(c)<32 or ord(c)==127 for c in value):return None
 try:
  parsed=urlsplit(value)
  if parsed.scheme in ('http','https'):
   if not parsed.hostname or not parsed.netloc or parsed.username is not None or parsed.password is not None:return None
   if '\\' in value or any(c.isspace() for c in value):return None
   if parsed.port is not None and not 1<=parsed.port<=65535:return None
   if any(k.lower() in {'token','access_token','api_key','apikey','password','secret','session'} for k,_ in parse_qsl(parsed.query)):return None
   return value
  if root is None:return None
  if parsed.scheme and not re.match(r'^[A-Za-z]:[\\/]',value):return None
  root=Path(root).resolve();candidate=Path(value)
  if not candidate.is_absolute():candidate=root/candidate
  if not candidate.resolve().is_relative_to(root):return None
  relative=candidate.relative_to(root)
  guarded=_internal(root,relative,_sibling('school_backup'))
  if not guarded.is_file():return None
  return quote(os.path.relpath(guarded,root/'ЦЕЛИ').replace('\\','/'),safe='/.-_~')
 except (ValueError,OSError):return None


def _link(value,label,root=None):
 target=_safe_link(value,root)
 if target is None:return '<span class="muted">'+_h(label)+' · ссылка не показана</span>'
 external=target.startswith(('http://','https://'))
 return '<a href="'+_h(target)+'"'+(' target="_blank" rel="noopener noreferrer"' if external else '')+'>'+_h(label)+'</a>'


def _badge(value,table=STATUSES):return '<span class="badge">'+_h(table.get(value,_text(value) or 'Не указано'))+'</span>'


def _origin(record):
 p=record.get('provenance');kind=p.get('kind') if isinstance(p,dict) else p
 parts=[ORIGINS.get(kind,'Происхождение не указано')]
 if isinstance(p,dict) and _text(p.get('recorded_on')):parts.append(_text(p['recorded_on']))
 markup='<span class="origin">'+_h(' · '.join(parts))+'</span>'
 if _text(record.get('source')):markup+='<p class="source">Источник: '+_h(record['source'])+'</p>'
 if isinstance(p,dict) and _text(p.get('evidence_ref')):markup+='<p class="source">Указатель: '+_h(p['evidence_ref'])+'</p>'
 return markup


def _facts(pairs):
 return '<dl class="facts">'+''.join('<div><dt>'+_h(label)+'</dt><dd>'+_h(value)+'</dd></div>' for label,value in pairs if _text(value))+'</dl>'


class _Context:
 def __init__(self,p,root):
  self.p=p;self.root=root
  self.maps={k:{r['id']:r for r in p[k] if isinstance(r.get('id'),str)} for k in FIELDS}
  self.goals={};self.stages={}
  def add(kind,identifier,goals=(),stages=()):
   if not isinstance(identifier,str):return
   self.goals.setdefault((kind,identifier),set()).update(x for x in goals if isinstance(x,str) and x in self.maps['goals'])
   self.stages.setdefault((kind,identifier),set()).update(x for x in stages if isinstance(x,str) and x in self.maps['milestones'])
  for g in p['goals']:add('goals',g['id'],[g['id']])
  for kind in ('future_scenarios','milestones','projects','trials','tasks'):
   for r in p[kind]:add(kind,r['id'],[r.get('goal_id')])
  for m in p['milestones']:
   gid=m.get('goal_id');mid=m['id'];add('milestones',mid,[gid],[mid]);add('goals',gid,[gid],[mid]);add('future_scenarios',m.get('scenario_id'),[gid],[mid])
   for field,kind in (('task_ids','tasks'),('topic_ids','topics'),('trial_ids','trials')):
    for rid in _array(m.get(field)):add(kind,rid,[gid],[mid])
  for kind in ('projects','trials'):
   for r in p[kind]:
    if kind=='projects':
     for tid in _array(r.get('task_ids')):add(kind,r['id'],[r.get('goal_id')],self.stages.get(('tasks',tid),set()))
    else:add('hypotheses',r.get('hypothesis_id'),self.goals.get((kind,r['id']),set()),self.stages.get((kind,r['id']),set()))
  for kind in ('checks','attempts','study_goals'):
   for r in p[kind]:
    for tid in _array(r.get('topic_ids')):add(kind,r['id'],self.goals.get(('topics',tid),set()),self.stages.get(('topics',tid),set()))
  for r in p['subjects']:
   for tid in _array(r.get('topic_ids')):add('subjects',r['id'],self.goals.get(('topics',tid),set()),self.stages.get(('topics',tid),set()))
  for r in p['resources']:
   for subject in p['subjects']:
    if r['id'] in _array(subject.get('resource_ids')):add('resources',r['id'],self.goals.get(('subjects',subject['id']),set()),self.stages.get(('subjects',subject['id']),set()))
  for r in p['sessions']:
   for field,kind in (('goal_ids','goals'),('goal_ids','study_goals'),('subject_ids','subjects'),('check_ids','checks')):
    for rid in _array(r.get(field)):add('sessions',r['id'],self.goals.get((kind,rid),set()),self.stages.get((kind,rid),set()))
  for r in p['communities']:add('communities',r['id'],_array(r.get('goal_ids')),_array(r.get('milestone_ids')))
  for r in p['hypotheses']:
   for rid in _array(r.get('evidence_ids')):
    for kind in ('answers','observations'):add(kind,rid,self.goals.get(('hypotheses',r['id']),set()),self.stages.get(('hypotheses',r['id']),set()))

 def ref(self,kind,identifier):
  r=self.maps[kind].get(identifier)
  if r is None:return '<span class="muted">'+_h(identifier)+' · связь не найдена</span>'
  label=r.get('title') or r.get('name') or r.get('action') or r.get('description') or r.get('id')
  return '<a href="#'+_token(kind,identifier)+'">'+_h(label)+'</a>'

 def refs(self,kind,ids):
  ids=_array(ids)
  return '<span class="ref-list">'+''.join('<span>'+self.ref(kind,x)+'</span>' for x in ids)+'</span>' if ids else '<span class="muted">Пока нет связей</span>'

 def card(self,kind,r,title,body,status=None,extra='',suffix=''):
  gid=' '.join(_token('goal',x) for x in sorted(self.goals.get((kind,r['id']),set())))
  mid=' '.join(_token('stage',x) for x in sorted(self.stages.get((kind,r['id']),set())))
  return '<article class="record glass '+extra+'" id="'+_token(kind,r['id'])+suffix+'" data-record data-goals="'+gid+'" data-stages="'+mid+'"><div class="card-top"><span class="record-id">'+_h(r['id'])+'</span>'+(_badge(status) if status else '')+'</div><h3>'+_h(title)+'</h3>'+body+_origin(r)+'</article>'


def _section(identifier,kicker,title,intro,body):
 return '<section class="section" id="'+identifier+'"><div class="section-heading"><span class="eyebrow">'+_h(kicker)+'</span><h2>'+_h(title)+'</h2><p>'+_h(intro)+'</p></div>'+body+'</section>'


def _wheel(balance):
 rows=[]
 for r in balance:
  if r.get('provenance')!='self_report' or not _text(r.get('source')):continue
  try:date.fromisoformat(_text(r.get('recorded_on')))
  except ValueError:continue
  score=r.get('score')
  if score is not None and not(type(score) in (int,float) and math.isfinite(score) and 0<=score<=10):continue
  if _text(r.get('domain')):rows.append(r)
 latest={}
 for r in rows:
  if r['domain'] not in latest or r['recorded_on']>=latest[r['domain']]['recorded_on']:latest[r['domain']]=r
 selected=list(latest.values());n=len(selected)
 base='<svg class="balance-wheel" viewBox="0 0 320 320" role="img" aria-label="Добровольные самооценки баланса; неизвестное не равно нулю"><defs><radialGradient id="balance-pearl"><stop stop-color="#fafcff"/><stop offset="1" stop-color="#dce6f5"/></radialGradient></defs><circle cx="160" cy="160" r="110" fill="url(#balance-pearl)" stroke="#fff"/>'
 for radius in (22,44,66,88,110):base+=f'<circle cx="160" cy="160" r="{radius}" fill="none" stroke="#aebfda" stroke-opacity=".42"/>'
 listing=''
 if not n:base+='<text x="160" y="153" text-anchor="middle" class="wheel-empty">Пока нет</text><text x="160" y="177" text-anchor="middle" class="wheel-empty">самооценок</text>'
 for i,r in enumerate(selected):
  a=-math.pi/2+2*math.pi*i/n;b=-math.pi/2+2*math.pi*(i+1)/n;mid=(a+b)/2
  point=lambda radius,angle:(160+radius*math.cos(angle),160+radius*math.sin(angle))
  end=point(110,a);base+=f'<path d="M160 160L{end[0]:.2f} {end[1]:.2f}" stroke="#bdcce2" stroke-width="1"/>'
  score=r.get('score');label='Не указано' if score is None else f'{score:g} / 10'
  if score is not None:
   radius=110*score/10;x,y=point(radius,mid)
   base+=f'<path d="M160 160L{x:.2f} {y:.2f}" stroke="var(--mint)" stroke-width="4" stroke-linecap="round"/><circle cx="{x:.2f}" cy="{y:.2f}" r="6" fill="var(--accent)" stroke="#fff" stroke-width="2"/>'
  lx,ly=point(130,mid);base+=f'<text x="{lx:.2f}" y="{ly:.2f}" text-anchor="middle" class="wheel-label">{i+1}</text>'
  listing+='<li><div><b>'+_h(str(i+1)+'. '+r['domain'])+'</b><strong>'+_h(label)+'</strong></div><small>'+_h(r['recorded_on'])+' · '+_h(r['source'])+'</small></li>'
 return '<div class="wheel-grid">'+base+'</svg><div><p class="note">Шкала 0–10 — только добровольная самооценка учащегося с датой и источником. Неизвестное не превращается в ноль.</p>'+('<ul class="balance-list">'+listing+'</ul>' if listing else _empty())+'</div></div>'

def _content(p,c):
 goals='';scenarios='';chain='';milestones='';tasks='';projects='';hypotheses='';trials='';study='';materials='';proofs='';evidence='';sessions='';communities=''
 for r in p['goals']:
  confirmation=r.get('confirmation') if isinstance(r.get('confirmation'),dict) else {}
  body=_facts([('Зачем',r.get('why')),('Отправная точка',r.get('baseline')),('Признак результата',r.get('success_criterion')),('Горизонт',r.get('horizon'))])
  body+='<p class="note">'+('Подтверждение учащегося записано.' if confirmation.get('confirmed') is True else 'Подтверждение учащегося пока не записано.')+'</p>'+_para(confirmation.get('evidence'))
  goals+=c.card('goals',r,r.get('title'),body)
 for r in p['future_scenarios']:
  body='<p>Цель: '+c.ref('goals',r.get('goal_id'))+'</p>'+_facts([('Возрастной ориентир',r.get('target_age'))])
  if r.get('assumptions'):body+='<div class="callout"><b>Условия и допущения</b>'+''.join(_para(x) for x in r['assumptions'])+'</div>'
  body+='<p class="note">Сценарий будущего — ориентир для выбора и пересмотра, не прогноз и не гарантия.</p>'
  scenarios+=c.card('future_scenarios',r,r.get('title'),body,r.get('target_status'))
 for m in p['milestones']:
  topic_ids=_array(m.get('topic_ids'));checks=[x['id'] for x in p['checks'] if set(_array(x.get('topic_ids')))&set(topic_ids)]
  nodes=[('Цель',c.ref('goals',m.get('goal_id'))),('Сценарий',c.ref('future_scenarios',m.get('scenario_id'))),('Веха',_h(m.get('title'))),('Задачи',c.refs('tasks',m.get('task_ids'))),('Темы',c.refs('topics',topic_ids)),('Проверки',c.refs('checks',checks))]
  body='<ol class="chain">'+''.join('<li><small>'+label+'</small><div>'+value+'</div></li>' for label,value in nodes)+'</ol>'
  chain+=c.card('milestones',m,m.get('title'),body,m.get('status'),'chain-card')
  ages=('от '+_text(m.get('age_from')) if m.get('age_from') is not None else '')+(' до '+_text(m.get('age_to')) if m.get('age_to') is not None else '')
  body=_facts([('Возрастное окно',ages),('Критерий',m.get('success_criterion'))])+'<p>Проба: '+c.refs('trials',m.get('trial_ids'))+'</p>'
  roles=[ROLES[x][0] for x in _array(m.get('support_role_ids')) if x in ROLES]
  if roles:body+='<p class="note">Функции сопровождения: '+_h(', '.join(roles))+'</p>'
  body+=_para(m.get('result_evidence'));milestones+=c.card('milestones',m,m.get('title'),body,m.get('status'),suffix='-detail')
 if not chain:chain='<div class="glass empty-chain"><div class="chain-labels">Цель <span>→</span> Сценарий <span>→</span> Веха <span>→</span> Задача <span>→</span> Тема <span>→</span> Проверка</div>'+_empty('Пока нет данных для связанного маршрута')+'</div>'
 for r in p['tasks']:
  body='<p>Цель: '+c.ref('goals',r.get('goal_id'))+'</p>'+_facts([('Когда',r.get('when')),('Ответственный',r.get('owner')),('Готово, когда',r.get('done_when')),('Проверка результата',r.get('verification')),('Усилие',r.get('effort')),('Что учесть',r.get('risk'))])
  body+='<p>Зависимости: '+c.refs('tasks',r.get('dependencies'))+'</p>'
  if r.get('result_evidence'):body+='<div class="proof"><b>Запись результата</b>'+_para(r['result_evidence'])+_badge(r.get('result_provenance'),ORIGINS)+'</div>'
  tasks+=c.card('tasks',r,r.get('action'),body,r.get('status'))
 for r in p['projects']:
  body='<p>Цель: '+c.ref('goals',r.get('goal_id'))+'</p><p>Задачи: '+c.refs('tasks',r.get('task_ids'))+'</p>'+_para(r.get('result_evidence'))
  projects+=c.card('projects',r,r.get('title'),body,r.get('status'))
 for r in p['hypotheses']:
  probe=r.get('probe') if isinstance(r.get('probe'),dict) else {};refs=''
  for rid in _array(r.get('evidence_ids')):
   kind='answers' if rid in c.maps['answers'] else 'observations';refs+='<span>'+c.ref(kind,rid)+'</span>'
  body='<div class="callout"><b>Что ещё неизвестно</b>'+_para(r.get('uncertainty'))+'</div><p>Основания: <span class="ref-list">'+(refs or 'Пока нет связей')+'</span></p>'
  body+=_facts([('Проба',probe.get('action')),('Время',probe.get('timebox')),('Что наблюдать',probe.get('observation')),('Критерий пробы',probe.get('success_criterion'))])
  hypotheses+=c.card('hypotheses',r,r.get('title'),body)
 for r in p['trials']:
  body='<p>Гипотеза: '+c.ref('hypotheses',r.get('hypothesis_id'))+'</p><p>Цель: '+c.ref('goals',r.get('goal_id'))+'</p>'+_facts([('Вопрос',r.get('question')),('Своё действие',r.get('action')),('Когда',r.get('when')),('Результат',r.get('result_evidence')),('Рефлексия',r.get('reflection'))])
  trials+=c.card('trials',r,r.get('title'),body,r.get('status'))
 for r in p['subjects']:
  body=_para(r.get('level_label'))+'<p>Темы: '+c.refs('topics',r.get('topic_ids'))+'</p><p>Материалы: '+c.refs('resources',r.get('resource_ids'))+'</p>'+_para(r.get('ai_rules_note'))
  study+=c.card('subjects',r,r.get('name'),body)
 for r in p['topics']:
  body='<p>Предмет: '+c.ref('subjects',r.get('subject_id'))+'</p>'+''.join(_para(x) for x in _array(r.get('learning_outcomes')))+'<p>Доказательства: '+c.refs('checks',r.get('evidence_check_ids'))+'</p>'
  study+=c.card('topics',r,r.get('title'),body,r.get('status'))
 for r in p['study_goals']:
  body=_facts([('Критерий',r.get('success_criterion'))])+'<p>Темы: '+c.refs('topics',r.get('topic_ids'))+'</p><p>Проверки: '+c.refs('checks',r.get('evidence_check_ids'))+'</p>'
  study+=c.card('study_goals',r,r.get('description'),body,r.get('status'))
 for r in p['resources']:
  body=_facts([('Авторы',', '.join(_array(r.get('authors')))),('Издание',r.get('edition')),('Год',r.get('year')),('Фактический доступ',r.get('access_status')),('Дата проверки',r.get('checked_on'))])
  if r.get('local_file'):body+='<p>'+_link(r['local_file'],'Локальный материал',c.root)+'</p>'
  if r.get('public_url'):body+='<p>'+_link(r['public_url'],'Источник в интернете')+'</p>'
  materials+=c.card('resources',r,r.get('title'),body)
 for r in p['checks']:
  body='<p>Темы: '+c.refs('topics',r.get('topic_ids'))+'</p><p>Попытка: '+c.ref('attempts',r.get('attempt_id'))+'</p>'+_facts([('Вид проверки',r.get('kind')),('Помощь',ASSISTANCE.get(r.get('assistance'),r.get('assistance'))),('Ответ был показан',r.get('answer_seen_before')),('Новое задание',r.get('task_new_to_learner')),('Дней после обучения',r.get('elapsed_days_since_learning'))])
  body+=''.join(_para(x) for x in _array(r.get('rubric')))
  proofs+=c.card('checks',r,'Проверка · '+_text(r.get('id')),body,r.get('outcome'))
 for r in p['attempts']:
  body=_facts([('Задание',r.get('prompt')),('Своё действие / ответ',r.get('learner_response')),('Помощь',ASSISTANCE.get(r.get('assistance'),r.get('assistance'))),('Обратная связь',r.get('feedback'))])
  proofs+=c.card('attempts',r,'Попытка · '+_text(r.get('id')),body,r.get('result'))
 for r in p['answers']:evidence+=c.card('answers',r,'Исходное сообщение · '+_text(r.get('id')),_para(r.get('answer')))
 for r in p['observations']:evidence+=c.card('observations',r,'Наблюдение · '+_text(r.get('id')),_para(r.get('evidence_summary')))
 for r in p['sessions']:
  body=_para(r.get('summary'))+_facts([('Своё действие',r.get('learner_action')),('Полученная помощь',r.get('help_given')),('Не проверено',r.get('not_verified')),('Следующий шаг',r.get('next_step'))])+'<p>Проверки: '+c.refs('checks',r.get('check_ids'))+'</p>'
  sessions+=c.card('sessions',r,r.get('date') or r.get('id'),body)
 for r in p['communities']:
  body='<p>'+_link(r.get('url'),'Открыть страницу сообщества')+'</p><p>Цели: '+c.refs('goals',r.get('goal_ids'))+'</p><p>Вехи: '+c.refs('milestones',r.get('milestone_ids'))+'</p>'+_para(r.get('evidence'))
  body+='<p class="note">Статус отражает сохранённую запись; участие и отправка сообщений из панели не выполняются.</p>'
  communities+=c.card('communities',r,r.get('title'),body,r.get('status'))
 balance_history=''.join(c.card('balance',r,r.get('domain'),_facts([('Самооценка',r.get('score')),('Дата',r.get('recorded_on'))])) for r in p['balance'])
 roles=''.join('<article class="role-card"><span class="role-glyph" aria-hidden="true">'+str(i+1)+'</span><div><h3>'+_h(title)+'</h3><p>'+_h(description)+'</p></div></article>' for i,(_, (title,description)) in enumerate(ROLES.items()))
 grid=lambda body:'<div class="records">'+(body or _empty())+'</div>'
 return ''.join([
  _section('goals','Смысл и ориентиры','Мои цели и сценарии','Выбранное направление можно уточнять. Условия будущего не становятся обещаниями результата.',grid(goals)+grid(scenarios)),
  _section('route','Связи, а не проценты','Маршрут от цели до проверки','Каждая стрелка опирается на сохранённый ID. Отсутствующую связь панель не достраивает.',chain+'<details class="glass detail-group"><summary>Критерии вех и функции сопровождения</summary>'+grid(milestones)+'</details>'),
  _section('actions','Своё действие','Задачи и проекты','Отметка завершения имеет источник и доказательство. Она не присваивает учебный навык.',grid(tasks)+grid(projects)),
  _section('directions','Гипотезы и опыт','Направления и профессиональные пробы','Самооценка, наблюдение и предположение агента имеют разные подписи.',grid(hypotheses)+grid(trials)),
  _section('study','Тема и материал','Текущая учёба','Знание проверяется своим объяснением или новой задачей. Чтение материала само по себе этого не доказывает.',grid(study)+'<details class="glass detail-group"><summary>Учебные источники и доступ к ним</summary>'+grid(materials)+'</details>'),
  _section('proofs','Что действительно наблюдали','Попытки и доказательства','Помощь, показанный ключ и отсрочка видны отдельно. Старые записи не объявляются новой проверкой.',grid(proofs)+'<details class="glass detail-group"><summary>Исходные сообщения и наблюдения</summary>'+grid(evidence)+'</details>'),
  _section('balance','Добровольно и с датой','Мой жизненный баланс','Здесь нет оценки характера, способностей или профессиональной пригодности.','<div class="glass balance-card">'+_wheel(p['balance'])+'</div><details class="glass detail-group"><summary>История самооценок</summary>'+grid(balance_history)+'</details>'),
  _section('environment','Среда и общение','Сообщества и возможности','Ссылка, проверка источника и реальное участие — разные состояния.',grid(communities)),
  _section('sessions','Точка продолжения','История своих шагов','Что сделано самостоятельно, где была помощь и что пока не проверено.',grid(sessions)),
  _section('roles','Один агент','Функции моего помощника','Это разные способы сопровождения одним агентом. Панель не запускает автономных помощников.','<div class="roles">'+roles+'</div>')])


CSS = r'''
:root{color-scheme:light;--ink:#23334e;--muted:#5b6e8a;--accent:#3d5bdf;--mint:#5ebfb6;--navy:#18294e;--line:#bdcce04d;--shadow:9px 12px 26px #54698d29,-7px -7px 19px #ffffffb8,inset 0 1px #ffffffd1}*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;color:var(--ink);font:16px/1.65 "Segoe UI Variable","Segoe UI",Arial,sans-serif;background:radial-gradient(ellipse at 90% 3%,#d5e1ffce,transparent 43%),radial-gradient(ellipse at 8% 68%,#d2ebe778,transparent 45%),linear-gradient(135deg,#e4e9f2,#d4deed 52%,#dce4ef);background-attachment:fixed}a{color:#3154b7;text-underline-offset:3px}a:hover{text-decoration-thickness:2px}button,select{font:inherit}a,select,summary{touch-action:manipulation}a:focus-visible,select:focus-visible,summary:focus-visible{outline:3px solid var(--accent);outline-offset:4px}.layout{display:grid;grid-template-columns:220px minmax(0,1fr);min-height:100vh}.sidebar{position:sticky;top:0;height:100vh;padding:32px 20px;background:linear-gradient(145deg,#f7f9fdc4,#d7e0efa8);border-right:1px solid #ffffffb3;display:flex;flex-direction:column;gap:24px}.brand{font-weight:800;font-size:23px;letter-spacing:-.045em;line-height:1.2}.brand span{color:#5570cc}.side-label{font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:#687d9c}.nav{display:flex;flex-direction:column;gap:6px}.nav a{padding:9px 12px;text-decoration:none;border:1px solid transparent;border-radius:12px;font-size:14px;color:#506684}.nav a:hover{background:#f4f7fc8a;border-color:#fff}.side-note{font-size:12px;color:var(--muted);margin-top:auto}.main{min-width:0;max-width:1500px;width:100%;margin:auto;padding:32px 36px 45px}.topline{display:flex;justify-content:space-between;gap:20px;align-items:start;margin-bottom:20px}.tag,.badge,.origin{font-size:11px;line-height:1.5;display:inline-block;background:#eef3ffa8;border:1px solid #ffffffc7;border-radius:8px;padding:5px 9px;color:#4866ad}.origin{margin-top:16px;color:#4d746d;background:#edf7f3b8}.badge{color:#4f668c;background:#f3f7ffc9}.meta{text-align:right;color:var(--muted);font-size:12px;overflow-wrap:anywhere}h1{font-size:clamp(30px,3vw,44px);line-height:1.14;letter-spacing:-.045em;margin:12px 0 15px}h2{font-size:27px;line-height:1.22;letter-spacing:-.035em;margin:8px 0 10px}h3{font-size:19px;line-height:1.35;letter-spacing:-.025em;margin:12px 0}.lead{max-width:850px;color:var(--muted);margin-bottom:25px}.eyebrow{text-transform:uppercase;letter-spacing:.09em;font-size:11px;color:#5a74b6;font-weight:750}.glass{position:relative;min-width:0;border-radius:22px;border:1px solid #ffffffc9;background:linear-gradient(135deg,#fafcffd4,#ebf0f8b3);box-shadow:var(--shadow);padding:25px;backdrop-filter:blur(12px)}.hero-grid{display:grid;grid-template-columns:1.18fr 1fr;gap:24px;margin-top:24px}.hero{padding:29px;border-radius:24px;border:1px solid #ffffff66;background:linear-gradient(125deg,#51b9bb,#5c80d4 58%,#7068dc);color:#fff;box-shadow:var(--shadow)}.hero h2{font-size:30px;line-height:1.24;margin-top:14px}.hero p{color:#f0f8ff;margin-bottom:10px}.hero small{color:#eef5ff}.next-card{background:linear-gradient(135deg,#314a75,#192b4d);color:#fff}.next-card p{font-size:19px;line-height:1.6;white-space:pre-wrap}.next-card .eyebrow{color:#b9d7ee}.hero .eyebrow{color:#f0fbff}.hero .empty{color:#f0f8ff}.filters{display:flex;flex-wrap:wrap;align-items:end;gap:15px;margin:26px 0 9px;padding:18px 20px}.filters label{font-size:12px;font-weight:650;color:#5a7293;display:flex;flex-direction:column;gap:6px;flex:1;min-width:160px}.filters select{border:1px solid #ffffffcc;border-radius:11px;padding:10px 13px;color:#2f4f7e;background:#edf2fa;box-shadow:inset 3px 3px 7px #809ac729,inset -3px -3px 7px #ffffffd9;max-width:100%}.filter-note{font-size:12px;color:var(--muted);margin:12px 4px}.section{margin-top:38px;scroll-margin-top:20px}.section-heading{max-width:900px;margin-bottom:21px}.section-heading>p{margin:0;font-size:14px;color:var(--muted)}.records{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:21px;margin-top:20px}.records>.empty{grid-column:1/-1;margin:0;padding:20px;border:1px dashed #aebfd6;border-radius:16px;background:#f3f7fd4d}.record{overflow-wrap:anywhere}.card-top{display:flex;align-items:start;justify-content:space-between;gap:12px}.record-id{font-size:11px;letter-spacing:.02em;color:#647b9c;overflow-wrap:anywhere}.body-text,.facts dd{white-space:pre-wrap}.record p{color:#536985;font-size:14px}.record p:last-child{margin-bottom:0}.source{font-size:11px!important;line-height:1.6;overflow-wrap:anywhere}.facts{font-size:14px;line-height:1.6;margin:14px 0}.facts>div{margin:12px 0}.facts dt{font-size:11px;text-transform:uppercase;letter-spacing:.04em;color:#6880a3;font-weight:700}.facts dd{margin:3px 0 0;color:#465e7f}.muted,.note,.empty{color:#607491}.note{font-size:13px}.empty{font-size:15px}.ref-list{display:flex;gap:6px;flex-wrap:wrap;align-items:start}.ref-list>span{display:inline-flex;border:1px solid #cad6e88a;background:#f3f7fc7a;border-radius:7px;padding:3px 7px;font-size:12px}.callout,.proof{padding:15px;border-radius:13px;margin:16px 0;background:#e5eefb87;border:1px solid #ffffff8a}.callout>b,.proof>b{font-size:12px;color:#4c6ba7}.callout p,.proof p{margin-bottom:0}.chain-card{margin:20px 0}.chain{padding:0;margin:20px 0 0;list-style:none;display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:12px}.chain>li{position:relative;background:linear-gradient(135deg,#f8fbffc9,#e1eaf7ad);border:1px solid #ffffffb3;border-radius:13px;padding:14px 11px;min-width:0}.chain>li:not(:last-child)::after{content:'→';position:absolute;right:-12px;top:39%;z-index:1;color:#6483bc}.chain small{display:block;font-size:10px;text-transform:uppercase;letter-spacing:.05em;color:#687fa0;margin-bottom:7px}.chain>li>div{font-size:12px;line-height:1.5}.chain .ref-list{display:block}.chain .ref-list>span{display:block;margin-bottom:5px}.empty-chain{margin-top:20px}.chain-labels{display:flex;flex-wrap:wrap;gap:10px;font-weight:650;color:#4a6691;font-size:14px}.chain-labels span{color:#80aaa9}.detail-group{margin-top:22px;padding:18px 22px}.detail-group summary{cursor:pointer;font-size:14px;font-weight:650;color:#47628b}.wheel-grid{display:grid;grid-template-columns:minmax(260px,.9fr) minmax(0,1.1fr);gap:26px;align-items:center}.balance-wheel{display:block;width:100%;max-width:365px;margin:auto}.wheel-empty{font:17px "Segoe UI",sans-serif;fill:#687e9c}.wheel-label{font:12px "Segoe UI",sans-serif;fill:#4b6388}.balance-list{padding:0;list-style:none;margin:0}.balance-list li{padding:12px 0;border-bottom:1px solid #bed0e04d}.balance-list li>div{display:flex;justify-content:space-between;gap:16px;font-size:14px}.balance-list strong{font-weight:650;color:#3758ad;white-space:nowrap}.balance-list small{display:block;font-size:11px;color:#627a98;overflow-wrap:anywhere;margin-top:4px}.roles{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.role-card{display:flex;gap:15px;padding:20px;background:#edf3fb73;border:1px solid #ffffffb3;border-radius:18px;min-width:0}.role-glyph{flex:none;display:grid;place-items:center;width:36px;height:36px;border-radius:12px;background:linear-gradient(135deg,#d2e8fa,#d1d7ff);color:#4c65a6;font-size:13px}.role-card h3{margin:0 0 6px;font-size:16px}.role-card p{margin:0;font-size:13px;color:var(--muted)}.footer{font-size:12px;color:var(--muted);padding-top:35px;margin-top:30px;border-top:1px solid #ffffffa6;line-height:1.8;overflow-wrap:anywhere}.mode-notice{border-left:4px solid #5d90ba;padding:12px 16px;margin:17px 0;background:#f1f6ff78;border-radius:8px;font-size:13px;color:#506d92}[hidden],.is-filtered{display:none!important}
@media(min-width:1500px){.main{padding:38px 44px}.records{gap:25px}.glass{padding:28px}}
@media(max-width:1150px){.layout{grid-template-columns:190px minmax(0,1fr)}.main{padding:28px}.sidebar{padding:28px 15px}.chain{grid-template-columns:repeat(3,minmax(0,1fr))}.chain>li:nth-child(3)::after{content:''}.wheel-grid{grid-template-columns:1fr}.balance-wheel{max-width:310px}}
@media(max-width:850px){.hero-grid,.records,.roles{grid-template-columns:1fr}.main{padding:25px}.hero h2{font-size:28px}.hero-grid{gap:20px}}
@media(max-width:650px){.layout{display:block}.sidebar{position:static;height:auto;padding:22px;border-right:0;border-bottom:1px solid #fff9;gap:13px}.sidebar .side-label,.side-note{display:none}.brand{font-size:22px}.nav{flex-direction:row;overflow:auto;gap:5px}.nav a{white-space:nowrap;font-size:12px;padding:8px 10px}.main{padding:24px 18px}.topline{flex-wrap:wrap;gap:12px}.meta{text-align:left}h1{font-size:32px}.glass,.hero{padding:23px;border-radius:20px}.hero h2{font-size:27px}.next-card p{font-size:17px}.filters{padding:17px}.filters label{min-width:0;flex-basis:100%}.section{margin-top:32px}h2{font-size:24px}.chain{grid-template-columns:1fr;gap:14px}.chain>li{padding:13px}.chain>li:not(:last-child)::after{content:'↓';right:50%;top:auto;bottom:-15px}.chain .ref-list>span{display:inline-flex;margin-right:5px}.wheel-grid{grid-template-columns:minmax(0,1fr);gap:10px}.balance-list li>div{font-size:13px}.card-top{flex-wrap:wrap}.records{gap:18px}.detail-group{padding:17px}.role-card{padding:18px}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}*,*::before,*::after{animation:none!important;transition:none!important}}
'''
SCRIPT = r'''(()=>{"use strict";const goal=document.getElementById('goal-filter'),stage=document.getElementById('stage-filter'),notice=document.getElementById('filter-notice');function update(){for(const card of document.querySelectorAll('[data-record]')){const goals=(card.dataset.goals||'').split(' ').filter(Boolean),stages=(card.dataset.stages||'').split(' ').filter(Boolean);const gm=goal.value==='all'||goals.length===0||goals.includes(goal.value),sm=stage.value==='all'||stages.length===0||stages.includes(stage.value);card.classList.toggle('is-filtered',!(gm&&sm));}notice.textContent='Изменён только вид панели. Учебные записи и статусы не менялись.';}goal.addEventListener('change',update);stage.addEventListener('change',update);})();'''


def _build_html(state,generated_at=None,root=None):
 p=_projection(state);c=_Context(p,root);nickname=_text(p.get('nickname'));title=(nickname+' · ' if nickname else '')+'Моя личная панель'
 primary=p['goals'][0] if p['goals'] else None
 hero_title=primary.get('title') if primary else 'Цель ещё не выбрана'
 hero_detail=(primary.get('why') or primary.get('success_criterion')) if primary else 'Пока нет данных'
 goal_options='<option value="all">Все цели</option>'+''.join('<option value="'+_token('goal',r['id'])+'">'+_h(r.get('title') or r['id'])+'</option>' for r in p['goals'])
 stage_options='<option value="all">Все этапы</option>'+''.join('<option value="'+_token('stage',r['id'])+'">'+_h(r.get('title') or r['id'])+'</option>' for r in p['milestones'])
 stage=STAGES.get(p.get('stage'),_text(p.get('stage')) or 'Не указан');mode=''
 if p.get('data_mode')=='synthetic_scenario':mode='<p class="mode-notice">Синтетический сценарий: это не данные реального учащегося. Записи попыток не доказывают обучение человека.</p>'
 elif p.get('data_mode')=='empty_profile':mode='<p class="mode-notice">Чистый профиль. Панель заполнится только своими целями, действиями и сохранёнными записями.</p>'
 navigation=[('goals','Цели и сценарии'),('route','Связанный маршрут'),('actions','Задачи и проекты'),('directions','Направления и пробы'),('study','Текущая учёба'),('proofs','Доказательства'),('balance','Жизненный баланс'),('environment','Среда'),('sessions','История шагов'),('roles','Функции агента')]
 nav=''.join('<a href="#'+key+'">'+label+'</a>' for key,label in navigation)
 rendered=generated_at or 'Предпросмотр без сохранения'
 return '<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'; script-src \'unsafe-inline\'; connect-src \'none\'; object-src \'none\'; base-uri \'none\'; form-action \'none\'"><title>'+_h(title)+'</title><style>'+CSS+'</style></head><body><div class="layout"><aside class="sidebar"><div class="brand">Личная <span>панель</span></div><div class="side-label">Мой маршрут развития</div><nav class="nav" aria-label="Разделы панели">'+nav+'</nav><p class="side-note">Локальное представление сохранённых данных. Действия выполняются вместе с агентом в проекте.</p></aside><main class="main"><div class="topline"><span class="tag">Источник: каноническое состояние</span><div class="meta">Ревизия '+_h(p.get('revision'))+' · '+_h(stage)+'<br>Обновление источника: '+_h(p.get('updated_at') or 'ещё не записано')+'</div></div><h1>'+_h(title)+'</h1><p class="lead">Свои цели, текущая учёба и профессиональные пробы — в одном связанном маршруте. Рядом с результатом видны его источник и границы проверки.</p>'+mode+'<div class="hero-grid"><article class="hero"><span class="eyebrow">Ориентир</span><h2>'+_h(hero_title)+'</h2>'+_para(hero_detail)+'<small>Приоритет и сценарий выбирает учащийся; панель их не назначает.</small></article><article class="glass next-card"><span class="eyebrow">Следующий небольшой шаг</span>'+_para(p.get('next_step') or 'Пока нет данных')+'<small>Источник: next_step</small></article></div><div class="glass filters"><label for="goal-filter">Цель<select id="goal-filter">'+goal_options+'</select></label><label for="stage-filter">Этап / веха<select id="stage-filter">'+stage_options+'</select></label></div><p id="filter-notice" class="filter-note" role="status">Фильтры меняют только представление. Записи без связей остаются видимыми. Для сохранения нового результата обратись к агенту.</p>'+_content(p,c)+'<footer class="footer"><b>Источник:</b> ДАННЫЕ/состояние.json · ревизия '+_h(p.get('revision'))+'<br><b>Время отрисовки:</b> '+_h(rendered)+'<br>Панель не изменяет состояние, не запускает фоновые службы и не отправляет данные в интернет. Самооценка, импорт, наблюдение и гипотеза не заменяют друг друга. Содержимое взято только из явно разрешённых полей.</footer></main></div><script>'+SCRIPT+'</script></body></html>'


def render_html(state):
 """Pure projection: no filesystem, clock, network or mutation.

 Local artifact paths are not clickable in this rootless preview. render(root)
 enables only existing artifact files guarded inside that root.
 """
 return _build_html(state)


def _stage_bytes(path,data,root,backup):
 path=_internal(root,path.relative_to(root),backup);path.parent.mkdir(parents=True,exist_ok=True)
 temp=_internal(root,path.relative_to(root).with_name(path.name+'.'+uuid.uuid4().hex+'.tmp'),backup)
 with temp.open('xb') as handle:handle.write(data);handle.flush();os.fsync(handle.fileno())
 if temp.read_bytes()!=data:raise RuntimeError('Dashboard staged-file readback failed')
 return temp


def _replace(source,target):
 for attempt in range(8):
  try:os.replace(source,target);return
  except PermissionError:
   if attempt==7:raise
   time.sleep(.025*(attempt+1))


def render(root):
 """Validate canonical state; atomically save current and two previous HTMLs."""
 root=Path(root).resolve()
 if not root.is_dir():raise ValueError('Dashboard root is not a directory')
 backup=_sibling('school_backup');contract=_sibling('progress_contract')
 lock=backup.operation_lock(root,'state-operation.lock') if backup is not None else contextlib.nullcontext()
 with lock:
  source=_internal(root,'ДАННЫЕ/состояние.json',backup);raw=source.read_bytes();state=json.loads(raw.decode('utf-8-sig'))
  if not isinstance(state,dict):raise ValueError('Canonical state must be an object')
  if contract is None and 'progression' in state:raise RuntimeError('Progression validator unavailable; dashboard was not replaced')
  if contract is not None:
   errors=contract.validate_progression(state)
   if errors:raise ValueError('Invalid progression: '+'; '.join(errors))
  generated_at=datetime.now(timezone.utc).isoformat();data=_build_html(state,generated_at,root).encode('utf-8')
  output=_internal(root,OUTPUT,backup);previous=_internal(root,HISTORY+'/previous.html',backup);previous2=_internal(root,HISTORY+'/previous2.html',backup)
  old=output.read_bytes() if output.is_file() else None;old_previous=previous.read_bytes() if previous.is_file() else None;staged=[]
  try:
   new_temp=_stage_bytes(output,data,root,backup);staged.append(new_temp)
   history_temp=_stage_bytes(previous,old,root,backup) if old is not None else None
   if history_temp:staged.append(history_temp)
   older_temp=_stage_bytes(previous2,old_previous,root,backup) if old is not None and old_previous is not None else None
   if older_temp:staged.append(older_temp)
   if source.read_bytes()!=raw:raise RuntimeError('Canonical state changed during rendering; retry with the current revision')
   _replace(new_temp,output)
   if output.read_bytes()!=data:raise RuntimeError('Dashboard output readback failed')
   # Rotate only after the new current HTML has been written and read back.
   if older_temp:_replace(older_temp,previous2)
   if history_temp:_replace(history_temp,previous)
   if history_temp and previous.read_bytes()!=old:raise RuntimeError('Previous dashboard readback failed')
   if older_temp and previous2.read_bytes()!=old_previous:raise RuntimeError('Second previous dashboard readback failed')
  finally:
   for temporary in staged:
    if temporary.exists():_internal(root,temporary.relative_to(root),backup).unlink()
  return {'saved':True,'path':str(output),'source_revision':state.get('revision'),'rendered_at':generated_at,
   'state_unchanged':source.read_bytes()==raw,'source_sha256':hashlib.sha256(raw).hexdigest(),
   'progression_validated':contract is not None,'previous_versions':int(previous.is_file())+int(previous2.is_file()),
   'read_only_projection':True,'external_network_used':False}


if __name__=='__main__':
 import argparse,sys
 parser=argparse.ArgumentParser(description='Render a local read-only learner dashboard')
 parser.add_argument('--root',default=str(Path(__file__).resolve().parent.parent));arguments=parser.parse_args()
 for stream in (sys.stdout,sys.stderr):
  if hasattr(stream,'reconfigure'):stream.reconfigure(encoding='utf-8',errors='backslashreplace')
 print(json.dumps(render(arguments.root),ensure_ascii=False))
