"""Optional career-guidance data contract; standard library, no network or model.

Validation checks structure and provenance links, not truth, psychometric validity,
future earnings, or the quality of advice. Legacy state without these optional
branches remains valid. The validator never changes its input.
"""
from __future__ import annotations

import argparse
from datetime import date
import json
import math
from pathlib import Path
import re
import sys

SCHEMA_VERSION = 'career-guidance-1.0'
DOMAINS = ('episodes', 'activities', 'strengths', 'values', 'environment',
           'confidence', 'future', 'resources', 'livelihood', 'market',
           'trials', 'synthesis')
FORBIDDEN_FIELDS = {'aptitude_percent', 'fit_percent', 'guaranteed_income'}


def empty_career_profile() -> dict:
    """Return a fresh, unfilled profile, never an assessment result."""
    return {
        'schema_version': SCHEMA_VERSION,
        'readout_status': 'not_started',
        'coverage': {name: {'status': 'open', 'answer_ids': [],
                            'summary': '', 'reason': ''} for name in DOMAINS},
        'life_budget': {'currency': None, 'region': None,
                        'monthly_net_target': None, 'target_basis': 'not_set',
                        'source_answer_ids': []},
        'review_limitations': [],
        'summary_confirmation': {'confirmed': False, 'evidence': ''},
    }


def _text(value) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _number(value) -> bool:
    return (isinstance(value, (int, float)) and not isinstance(value, bool)
            and value > 0 and (not isinstance(value, float) or math.isfinite(value)))


def _iso_date(value) -> bool:
    if not isinstance(value, str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}', value):
        return False
    try:
        date.fromisoformat(value)
    except ValueError:
        return False
    return True


def _ids(value) -> bool:
    return (isinstance(value, list) and all(_text(item) for item in value)
            and len(value) == len(set(value)))


def _statements(value) -> bool:
    return isinstance(value, list) and all(_text(item) for item in value)


def _records(value) -> list:
    return value if isinstance(value, list) else []


def validate_career_profile(state) -> list[str]:
    """Validate optional career branches of a full canonical learner state.

    Missing career_profile and career_economics branches are compatible with old
    versions. New career structures cannot record aptitude percentages or a
    guaranteed income. Other unrelated personal state is deliberately not scanned.
    """
    errors: list[str] = []

    def need(condition, message):
        if not condition:
            errors.append(message)

    if not isinstance(state, dict):
        return ['career: state must be an object']
    orientation = state.get('orientation')
    orientation = orientation if isinstance(orientation, dict) else {}
    discovery = state.get('discovery')
    discovery = discovery if isinstance(discovery, dict) else {}
    research = state.get('research')
    research = research if isinstance(research, dict) else {}
    answer_ids = {item['id'] for item in _records(discovery.get('answers'))
                  if isinstance(item, dict) and _text(item.get('id'))}
    sources = {item['id']: item for item in _records(research.get('sources'))
               if isinstance(item, dict) and _text(item.get('id'))}
    options = _records(research.get('options'))

    def scan_forbidden(value, where, visited=None):
        if visited is None:
            visited = set()
        if not isinstance(value, (dict, list)) or id(value) in visited:
            return
        visited.add(id(value))
        if isinstance(value, dict):
            for key, item in value.items():
                need(key not in FORBIDDEN_FIELDS,
                     where + '.' + str(key) + ': unsupported aptitude/guarantee field')
                scan_forbidden(item, where + '.' + str(key), visited)
        else:
            for index, item in enumerate(value):
                scan_forbidden(item, where + '[' + str(index) + ']', visited)

    def check_answer_links(value, where):
        valid = _ids(value)
        need(valid, where + ': unique nonempty answer IDs required')
        if valid:
            need(set(value) <= answer_ids, where + ': unknown discovery answer ID')

    # The economics extension may exist independently of a newly added profile.
    unknown_economics = False
    for index, option in enumerate(options):
        if not isinstance(option, dict) or 'career_economics' not in option:
            continue
        where = 'research.options[' + str(index) + '].career_economics'
        economics = option['career_economics']
        need(isinstance(economics, dict), where + ': object required')
        if not isinstance(economics, dict):
            continue
        scan_forbidden(economics, where)
        status = economics.get('status')
        need(status in ('unknown', 'sourced'), where + '.status: unknown or sourced required')
        earnings = economics.get('earnings')
        need(isinstance(earnings, list), where + '.earnings: list required')
        if status == 'unknown':
            unknown_economics = True
            need(earnings == [], where + ': unknown earnings must remain an empty list')
            need(_text(economics.get('next_verification')),
                 where + '.next_verification: concrete next check required')
        if status == 'sourced':
            need(isinstance(earnings, list) and bool(earnings),
                 where + ': sourced earnings need at least one record')
            for field in ('currency', 'region', 'limits'):
                need(_text(economics.get(field)), where + '.' + field + ': text required')
        if not isinstance(earnings, list):
            continue
        for salary_index, salary in enumerate(earnings):
            point = where + '.earnings[' + str(salary_index) + ']'
            need(isinstance(salary, dict), point + ': object required')
            if not isinstance(salary, dict):
                continue
            low, high = salary.get('low'), salary.get('high')
            need(_number(low) and _number(high), point + ': positive finite numeric bounds required')
            if _number(low) and _number(high):
                need(low <= high, point + ': low cannot exceed high')
            need(salary.get('pay_period') in ('month', 'year', 'hour'),
                 point + '.pay_period: month/year/hour required')
            need(salary.get('pay_basis') in ('gross', 'net', 'unspecified'),
                 point + '.pay_basis: gross/net/unspecified required')
            need(salary.get('experience_band') in ('entry', 'experienced', 'all', 'unspecified'),
                 point + '.experience_band: entry/experienced/all/unspecified required')
            need(salary.get('statistic') in ('advertised_range', 'median', 'mean', 'reported_range'),
                 point + '.statistic: supported wage statistic required')
            need(_iso_date(salary.get('checked_at')), point + '.checked_at: valid YYYY-MM-DD required')
            for field in ('observed_period', 'sample_note'):
                need(_text(salary.get(field)), point + '.' + field + ': text required')
            ids = salary.get('source_ids')
            need(_ids(ids) and bool(ids), point + '.source_ids: nonempty unique source IDs required')
            if _ids(ids):
                for source_id in ids:
                    source = sources.get(source_id)
                    need(source is not None, point + ': unknown research source ' + source_id)
                    if source is not None:
                        need(source.get('status') == 'read',
                             point + ': earnings require an actually read source ' + source_id)

    if 'career_profile' not in orientation:
        return errors
    profile = orientation['career_profile']
    need(isinstance(profile, dict), 'orientation.career_profile: object required')
    if not isinstance(profile, dict):
        return errors
    scan_forbidden(profile, 'orientation.career_profile')
    need(profile.get('schema_version') == SCHEMA_VERSION, 'career_profile.schema_version: unsupported version')
    readout_status = profile.get('readout_status')
    need(readout_status in ('not_started', 'partial', 'review_ready', 'reviewed'),
         'career_profile.readout_status: invalid status')
    final_readout = readout_status in ('review_ready', 'reviewed')
    coverage = profile.get('coverage')
    need(isinstance(coverage, dict), 'career_profile.coverage: object required')
    deferred = False
    if isinstance(coverage, dict):
        need(set(coverage) <= set(DOMAINS), 'career_profile.coverage: unknown domain')
        for domain in DOMAINS:
            where = 'career_profile.coverage.' + domain
            item = coverage.get(domain)
            need(isinstance(item, dict), where + ': object required')
            if not isinstance(item, dict):
                continue
            status = item.get('status')
            need(status in ('open', 'discussed', 'deferred'), where + '.status: invalid status')
            check_answer_links(item.get('answer_ids'), where + '.answer_ids')
            need(isinstance(item.get('summary'), str), where + '.summary: string required')
            need(isinstance(item.get('reason'), str), where + '.reason: string required')
            if status == 'discussed':
                need(_text(item.get('summary')), where + ': substantive summary required')
                need(_ids(item.get('answer_ids')) and bool(item.get('answer_ids')),
                     where + ': discussed domain must reference an actual answer')
            elif status == 'deferred':
                deferred = True
                need(_text(item.get('reason')) and _text(item.get('summary')),
                     where + ': deferred domain needs reason and summary')
            if final_readout:
                need(status in ('discussed', 'deferred'), where + ': cannot remain open for a readout')

    budget = profile.get('life_budget')
    need(isinstance(budget, dict), 'career_profile.life_budget: object required')
    if isinstance(budget, dict):
        basis = budget.get('target_basis')
        need(basis in ('not_set', 'user_goal', 'budget_estimate'),
             'career_profile.life_budget.target_basis: invalid basis')
        for field in ('currency', 'region'):
            need(budget.get(field) is None or _text(budget.get(field)),
                 'career_profile.life_budget.' + field + ': null or nonempty text required')
        check_answer_links(budget.get('source_answer_ids'), 'career_profile.life_budget.source_answer_ids')
        target = budget.get('monthly_net_target')
        need(target is None or _number(target),
             'career_profile.life_budget.monthly_net_target: null or positive finite number required')
        if target is not None:
            need(basis in ('user_goal', 'budget_estimate'),
                 'career_profile.life_budget: a numeric goal needs an explicit target basis')
            need(_text(budget.get('currency')), 'career_profile.life_budget: a numeric goal needs currency')
            need(_ids(budget.get('source_answer_ids')) and bool(budget.get('source_answer_ids')),
                 'career_profile.life_budget: a numeric goal needs its source answer')
        if basis in ('user_goal', 'budget_estimate'):
            need(_number(target), 'career_profile.life_budget: selected basis needs a numeric goal')

    limitations = profile.get('review_limitations')
    need(_statements(limitations), 'career_profile.review_limitations: list of nonempty explanations required')
    critical_gaps = profile.get('critical_gaps', [])
    need(_statements(critical_gaps), 'career_profile.critical_gaps: list of nonempty gaps required')
    confirmation = profile.get('summary_confirmation')
    need(isinstance(confirmation, dict), 'career_profile.summary_confirmation: object required')
    if isinstance(confirmation, dict):
        need(isinstance(confirmation.get('confirmed'), bool),
             'career_profile.summary_confirmation.confirmed: boolean required')
        need(isinstance(confirmation.get('evidence'), str),
             'career_profile.summary_confirmation.evidence: string required')
        if confirmation.get('confirmed') is True:
            need(_text(confirmation.get('evidence')),
                 'career_profile.summary_confirmation: confirmation requires actual evidence')
    if final_readout:
        hypotheses = _records(orientation.get('hypotheses'))
        hypothesis_ids = {item['id'] for item in hypotheses
                          if isinstance(item, dict) and _text(item.get('id')) and _text(item.get('title'))}
        option_ids = {item['id'] for item in options
                      if isinstance(item, dict) and _text(item.get('id')) and _text(item.get('title'))}
        need(len(hypothesis_ids) >= 2, 'career_profile: readout needs at least two existing hypotheses')
        need(len(option_ids) >= 2, 'career_profile: readout needs at least two existing research options')
        for index, option in enumerate(options):
            need(isinstance(option, dict) and 'career_economics' in option,
                 'career_profile: readout option [' + str(index)
                 + '] needs career_economics, including an explicit unknown with next_verification when data is missing')
        if deferred or critical_gaps or research.get('critical_gaps') or unknown_economics:
            need(_statements(limitations) and bool(limitations),
                 'career_profile: readout with deferred sections or gaps must state its limitations')
        if readout_status == 'reviewed':
            need(isinstance(confirmation, dict) and confirmation.get('confirmed') is True
                 and _text(confirmation.get('evidence')),
                 'career_profile: reviewed status requires learner confirmation')
    return errors


def main(argv=None) -> int:
    """Print a template or validate a full state; do not modify any file."""
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8', errors='backslashreplace')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('template', 'validate'))
    parser.add_argument('--file', type=Path)
    args = parser.parse_args(argv)
    if args.action == 'template':
        print(json.dumps(empty_career_profile(), ensure_ascii=False, indent=2))
        return 0
    if args.file is None:
        parser.error('--file is required for validate')
    try:
        state = json.loads(args.file.read_text(encoding='utf-8-sig'))
        errors = validate_career_profile(state)
    except (OSError, ValueError, TypeError, RecursionError) as error:
        errors = ['career: cannot read/validate state: ' + str(error)]
    print(json.dumps({'valid': not errors, 'errors': errors,
                      'scope': 'structure and provenance links only; not psychometric or earnings verification'},
                     ensure_ascii=False))
    return 2 if errors else 0


if __name__ == '__main__':
    raise SystemExit(main())
